/**
 * Abstract syntax tree: representing expressions.
 */
package prev.data.ast.tree.expr;
