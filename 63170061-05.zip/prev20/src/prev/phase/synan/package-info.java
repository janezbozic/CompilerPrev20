/**
 * Syntax analysis.
 */
package prev.phase.synan;
