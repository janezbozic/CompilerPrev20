/**
 * Compiler for PREV'20 programming language producing MMIX assembly code.
 */
package prev;