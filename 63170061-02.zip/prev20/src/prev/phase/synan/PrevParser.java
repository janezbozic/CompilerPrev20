// Generated from synan/PrevParser.g4 by ANTLR 4.8


	package prev.phase.synan;
	
	import java.util.*;
	
	import prev.common.report.*;
	import prev.phase.lexan.*;


import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PrevParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		COMMENT=1, CONST_CHAR=2, CONST_STRING=3, CONST_INTEGER=4, CONST_LITERAL=5, 
		KW_BOOLEAN=6, KW_CHAR=7, KW_DEL=8, KW_DO=9, KW_ELSE=10, KW_FUN=11, KW_IF=12, 
		KW_INTEGER=13, KW_NEW=14, KW_THEN=15, KW_TYP=16, KW_VAR=17, KW_VOID=18, 
		KW_WHERE=19, KW_WHILE=20, CONST_BOOLEAN=21, CONST_VOID=22, IDENTIFIER=23, 
		SIM_LPAR=24, SIM_RPAR=25, SIM_LSQLBR=26, SIM_RSQLBR=27, SIM_LSQRBR=28, 
		SIM_RSQRBR=29, SIM_DOT=30, SIM_COM=31, SIM_COL=32, SIM_SCOL=33, SIM_AND=34, 
		SIM_LINE=35, SIM_EKSP=36, SIM_EQU=37, SIM_NEQU=38, SIM_LT=39, SIM_GT=40, 
		SIM_LTEQU=41, SIM_GTEQU=42, SIM_STAR=43, SIM_SLH=44, SIM_PRCNT=45, SIM_PLUS=46, 
		SIM_MINUS=47, SIM_TOP=48, SIM_IS=49, SPACE=50, TAB=51, ERROR=52;
	public static final int
		RULE_source = 0, RULE_source_p = 1, RULE_decl = 2, RULE_decl_p = 3, RULE_decl_args = 4, 
		RULE_type = 5, RULE_type_p = 6, RULE_type_args = 7, RULE_expr = 8, RULE_e_p = 9, 
		RULE_t = 10, RULE_t_p = 11, RULE_f = 12, RULE_f_p = 13, RULE_g = 14, RULE_g_p = 15, 
		RULE_i = 16, RULE_i_p = 17, RULE_j = 18, RULE_j_p = 19, RULE_k = 20, RULE_m = 21, 
		RULE_m_p = 22, RULE_n = 23, RULE_n_p = 24, RULE_n_pp = 25, RULE_expr_args = 26, 
		RULE_stmnt_args = 27, RULE_stmnt = 28, RULE_stmnt_p = 29;
	private static String[] makeRuleNames() {
		return new String[] {
			"source", "source_p", "decl", "decl_p", "decl_args", "type", "type_p", 
			"type_args", "expr", "e_p", "t", "t_p", "f", "f_p", "g", "g_p", "i", 
			"i_p", "j", "j_p", "k", "m", "m_p", "n", "n_p", "n_pp", "expr_args", 
			"stmnt_args", "stmnt", "stmnt_p"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, "'nil'", "'boolean'", "'char'", "'del'", 
			"'do'", "'else'", "'fun'", "'if'", "'integer'", "'new'", "'then'", "'typ'", 
			"'var'", "'void'", "'where'", "'while'", null, "'none'", null, "'('", 
			"')'", "'{'", "'}'", "'['", "']'", "'.'", "','", "':'", "';'", "'&'", 
			"'|'", "'!'", "'=='", "'!='", "'<'", "'>'", "'<='", "'>='", "'*'", "'/'", 
			"'%'", "'+'", "'-'", "'^'", "'='"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "COMMENT", "CONST_CHAR", "CONST_STRING", "CONST_INTEGER", "CONST_LITERAL", 
			"KW_BOOLEAN", "KW_CHAR", "KW_DEL", "KW_DO", "KW_ELSE", "KW_FUN", "KW_IF", 
			"KW_INTEGER", "KW_NEW", "KW_THEN", "KW_TYP", "KW_VAR", "KW_VOID", "KW_WHERE", 
			"KW_WHILE", "CONST_BOOLEAN", "CONST_VOID", "IDENTIFIER", "SIM_LPAR", 
			"SIM_RPAR", "SIM_LSQLBR", "SIM_RSQLBR", "SIM_LSQRBR", "SIM_RSQRBR", "SIM_DOT", 
			"SIM_COM", "SIM_COL", "SIM_SCOL", "SIM_AND", "SIM_LINE", "SIM_EKSP", 
			"SIM_EQU", "SIM_NEQU", "SIM_LT", "SIM_GT", "SIM_LTEQU", "SIM_GTEQU", 
			"SIM_STAR", "SIM_SLH", "SIM_PRCNT", "SIM_PLUS", "SIM_MINUS", "SIM_TOP", 
			"SIM_IS", "SPACE", "TAB", "ERROR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "PrevParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public PrevParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class SourceContext extends ParserRuleContext {
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public TerminalNode EOF() { return getToken(PrevParser.EOF, 0); }
		public SourceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_source; }
	}

	public final SourceContext source() throws RecognitionException {
		SourceContext _localctx = new SourceContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_source);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			decl();
			setState(61);
			source_p();
			setState(62);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Source_pContext extends ParserRuleContext {
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public Source_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_source_p; }
	}

	public final Source_pContext source_p() throws RecognitionException {
		Source_pContext _localctx = new Source_pContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_source_p);
		try {
			setState(68);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_FUN:
			case KW_TYP:
			case KW_VAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(64);
				decl();
				setState(65);
				source_p();
				}
				break;
			case EOF:
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclContext extends ParserRuleContext {
		public TerminalNode KW_TYP() { return getToken(PrevParser.KW_TYP, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_IS() { return getToken(PrevParser.SIM_IS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode KW_VAR() { return getToken(PrevParser.KW_VAR, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TerminalNode KW_FUN() { return getToken(PrevParser.KW_FUN, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public Decl_pContext decl_p() {
			return getRuleContext(Decl_pContext.class,0);
		}
		public DeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl; }
	}

	public final DeclContext decl() throws RecognitionException {
		DeclContext _localctx = new DeclContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_decl);
		try {
			setState(82);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_TYP:
				enterOuterAlt(_localctx, 1);
				{
				setState(70);
				match(KW_TYP);
				setState(71);
				match(IDENTIFIER);
				setState(72);
				match(SIM_IS);
				setState(73);
				type();
				}
				break;
			case KW_VAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(74);
				match(KW_VAR);
				setState(75);
				match(IDENTIFIER);
				setState(76);
				match(SIM_COL);
				setState(77);
				type();
				}
				break;
			case KW_FUN:
				enterOuterAlt(_localctx, 3);
				{
				setState(78);
				match(KW_FUN);
				setState(79);
				match(IDENTIFIER);
				setState(80);
				match(SIM_LPAR);
				setState(81);
				decl_p();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Decl_pContext extends ParserRuleContext {
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public List<TerminalNode> SIM_COL() { return getTokens(PrevParser.SIM_COL); }
		public TerminalNode SIM_COL(int i) {
			return getToken(PrevParser.SIM_COL, i);
		}
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public TerminalNode SIM_IS() { return getToken(PrevParser.SIM_IS, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public Decl_argsContext decl_args() {
			return getRuleContext(Decl_argsContext.class,0);
		}
		public Decl_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_p; }
	}

	public final Decl_pContext decl_p() throws RecognitionException {
		Decl_pContext _localctx = new Decl_pContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_decl_p);
		try {
			setState(100);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_RPAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(84);
				match(SIM_RPAR);
				setState(85);
				match(SIM_COL);
				setState(86);
				type();
				setState(87);
				match(SIM_IS);
				setState(88);
				expr();
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(90);
				match(IDENTIFIER);
				setState(91);
				match(SIM_COL);
				setState(92);
				type();
				setState(93);
				decl_args();
				setState(94);
				match(SIM_RPAR);
				setState(95);
				match(SIM_COL);
				setState(96);
				type();
				setState(97);
				match(SIM_IS);
				setState(98);
				expr();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Decl_argsContext extends ParserRuleContext {
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Decl_argsContext decl_args() {
			return getRuleContext(Decl_argsContext.class,0);
		}
		public Decl_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_args; }
	}

	public final Decl_argsContext decl_args() throws RecognitionException {
		Decl_argsContext _localctx = new Decl_argsContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_decl_args);
		try {
			setState(109);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(102);
				match(SIM_COM);
				setState(103);
				match(IDENTIFIER);
				setState(104);
				match(SIM_COL);
				setState(105);
				type();
				setState(106);
				decl_args();
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public TerminalNode KW_BOOLEAN() { return getToken(PrevParser.KW_BOOLEAN, 0); }
		public Type_pContext type_p() {
			return getRuleContext(Type_pContext.class,0);
		}
		public TerminalNode KW_CHAR() { return getToken(PrevParser.KW_CHAR, 0); }
		public TerminalNode KW_INTEGER() { return getToken(PrevParser.KW_INTEGER, 0); }
		public TerminalNode KW_VOID() { return getToken(PrevParser.KW_VOID, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public Type_argsContext type_args() {
			return getRuleContext(Type_argsContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_type);
		try {
			setState(138);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_BOOLEAN:
				enterOuterAlt(_localctx, 1);
				{
				setState(111);
				match(KW_BOOLEAN);
				setState(112);
				type_p();
				}
				break;
			case KW_CHAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(113);
				match(KW_CHAR);
				setState(114);
				type_p();
				}
				break;
			case KW_INTEGER:
				enterOuterAlt(_localctx, 3);
				{
				setState(115);
				match(KW_INTEGER);
				setState(116);
				type_p();
				}
				break;
			case KW_VOID:
				enterOuterAlt(_localctx, 4);
				{
				setState(117);
				match(KW_VOID);
				setState(118);
				type_p();
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 5);
				{
				setState(119);
				match(IDENTIFIER);
				setState(120);
				type_p();
				}
				break;
			case SIM_TOP:
				enterOuterAlt(_localctx, 6);
				{
				setState(121);
				match(SIM_TOP);
				setState(122);
				type();
				setState(123);
				type_p();
				}
				break;
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 7);
				{
				setState(125);
				match(SIM_LSQLBR);
				setState(126);
				match(IDENTIFIER);
				setState(127);
				match(SIM_COL);
				setState(128);
				type();
				setState(129);
				type_args();
				setState(130);
				match(SIM_RSQLBR);
				setState(131);
				type_p();
				}
				break;
			case SIM_LPAR:
				enterOuterAlt(_localctx, 8);
				{
				setState(133);
				match(SIM_LPAR);
				setState(134);
				type();
				setState(135);
				match(SIM_RPAR);
				setState(136);
				type_p();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_pContext extends ParserRuleContext {
		public TerminalNode SIM_LSQRBR() { return getToken(PrevParser.SIM_LSQRBR, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode SIM_RSQRBR() { return getToken(PrevParser.SIM_RSQRBR, 0); }
		public Type_pContext type_p() {
			return getRuleContext(Type_pContext.class,0);
		}
		public Type_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_p; }
	}

	public final Type_pContext type_p() throws RecognitionException {
		Type_pContext _localctx = new Type_pContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_type_p);
		try {
			setState(146);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(140);
				match(SIM_LSQRBR);
				setState(141);
				expr();
				setState(142);
				match(SIM_RSQRBR);
				setState(143);
				type_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_argsContext extends ParserRuleContext {
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Type_argsContext type_args() {
			return getRuleContext(Type_argsContext.class,0);
		}
		public Type_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_args; }
	}

	public final Type_argsContext type_args() throws RecognitionException {
		Type_argsContext _localctx = new Type_argsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_type_args);
		try {
			setState(155);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(148);
				match(SIM_COM);
				setState(149);
				match(IDENTIFIER);
				setState(150);
				match(SIM_COL);
				setState(151);
				type();
				setState(152);
				type_args();
				}
				break;
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public TContext t() {
			return getRuleContext(TContext.class,0);
		}
		public E_pContext e_p() {
			return getRuleContext(E_pContext.class,0);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_expr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(157);
			t();
			setState(158);
			e_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class E_pContext extends ParserRuleContext {
		public TerminalNode KW_WHERE() { return getToken(PrevParser.KW_WHERE, 0); }
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public E_pContext e_p() {
			return getRuleContext(E_pContext.class,0);
		}
		public E_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_e_p; }
	}

	public final E_pContext e_p() throws RecognitionException {
		E_pContext _localctx = new E_pContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_e_p);
		try {
			setState(168);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(160);
				match(KW_WHERE);
				setState(161);
				match(SIM_LSQLBR);
				setState(162);
				decl();
				setState(163);
				source_p();
				setState(164);
				match(SIM_RSQLBR);
				setState(165);
				e_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TContext extends ParserRuleContext {
		public FContext f() {
			return getRuleContext(FContext.class,0);
		}
		public T_pContext t_p() {
			return getRuleContext(T_pContext.class,0);
		}
		public TContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_t; }
	}

	public final TContext t() throws RecognitionException {
		TContext _localctx = new TContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_t);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(170);
			f();
			setState(171);
			t_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class T_pContext extends ParserRuleContext {
		public TerminalNode SIM_LINE() { return getToken(PrevParser.SIM_LINE, 0); }
		public FContext f() {
			return getRuleContext(FContext.class,0);
		}
		public T_pContext t_p() {
			return getRuleContext(T_pContext.class,0);
		}
		public T_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_t_p; }
	}

	public final T_pContext t_p() throws RecognitionException {
		T_pContext _localctx = new T_pContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_t_p);
		try {
			setState(178);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(173);
				match(SIM_LINE);
				setState(174);
				f();
				setState(175);
				t_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FContext extends ParserRuleContext {
		public GContext g() {
			return getRuleContext(GContext.class,0);
		}
		public F_pContext f_p() {
			return getRuleContext(F_pContext.class,0);
		}
		public FContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_f; }
	}

	public final FContext f() throws RecognitionException {
		FContext _localctx = new FContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_f);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(180);
			g();
			setState(181);
			f_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class F_pContext extends ParserRuleContext {
		public TerminalNode SIM_AND() { return getToken(PrevParser.SIM_AND, 0); }
		public GContext g() {
			return getRuleContext(GContext.class,0);
		}
		public F_pContext f_p() {
			return getRuleContext(F_pContext.class,0);
		}
		public F_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_f_p; }
	}

	public final F_pContext f_p() throws RecognitionException {
		F_pContext _localctx = new F_pContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_f_p);
		try {
			setState(188);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(183);
				match(SIM_AND);
				setState(184);
				g();
				setState(185);
				f_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GContext extends ParserRuleContext {
		public IContext i() {
			return getRuleContext(IContext.class,0);
		}
		public G_pContext g_p() {
			return getRuleContext(G_pContext.class,0);
		}
		public GContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_g; }
	}

	public final GContext g() throws RecognitionException {
		GContext _localctx = new GContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_g);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(190);
			i();
			setState(191);
			g_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class G_pContext extends ParserRuleContext {
		public TerminalNode SIM_EQU() { return getToken(PrevParser.SIM_EQU, 0); }
		public IContext i() {
			return getRuleContext(IContext.class,0);
		}
		public TerminalNode SIM_NEQU() { return getToken(PrevParser.SIM_NEQU, 0); }
		public TerminalNode SIM_LT() { return getToken(PrevParser.SIM_LT, 0); }
		public TerminalNode SIM_GT() { return getToken(PrevParser.SIM_GT, 0); }
		public TerminalNode SIM_LTEQU() { return getToken(PrevParser.SIM_LTEQU, 0); }
		public TerminalNode SIM_GTEQU() { return getToken(PrevParser.SIM_GTEQU, 0); }
		public G_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_g_p; }
	}

	public final G_pContext g_p() throws RecognitionException {
		G_pContext _localctx = new G_pContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_g_p);
		try {
			setState(206);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(193);
				match(SIM_EQU);
				setState(194);
				i();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(195);
				match(SIM_NEQU);
				setState(196);
				i();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(197);
				match(SIM_LT);
				setState(198);
				i();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(199);
				match(SIM_GT);
				setState(200);
				i();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(201);
				match(SIM_LTEQU);
				setState(202);
				i();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(203);
				match(SIM_GTEQU);
				setState(204);
				i();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IContext extends ParserRuleContext {
		public JContext j() {
			return getRuleContext(JContext.class,0);
		}
		public I_pContext i_p() {
			return getRuleContext(I_pContext.class,0);
		}
		public IContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_i; }
	}

	public final IContext i() throws RecognitionException {
		IContext _localctx = new IContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_i);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(208);
			j();
			setState(209);
			i_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class I_pContext extends ParserRuleContext {
		public TerminalNode SIM_PLUS() { return getToken(PrevParser.SIM_PLUS, 0); }
		public JContext j() {
			return getRuleContext(JContext.class,0);
		}
		public I_pContext i_p() {
			return getRuleContext(I_pContext.class,0);
		}
		public TerminalNode SIM_MINUS() { return getToken(PrevParser.SIM_MINUS, 0); }
		public I_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_i_p; }
	}

	public final I_pContext i_p() throws RecognitionException {
		I_pContext _localctx = new I_pContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_i_p);
		try {
			setState(220);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(211);
				match(SIM_PLUS);
				setState(212);
				j();
				setState(213);
				i_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(215);
				match(SIM_MINUS);
				setState(216);
				j();
				setState(217);
				i_p();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JContext extends ParserRuleContext {
		public KContext k() {
			return getRuleContext(KContext.class,0);
		}
		public J_pContext j_p() {
			return getRuleContext(J_pContext.class,0);
		}
		public JContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_j; }
	}

	public final JContext j() throws RecognitionException {
		JContext _localctx = new JContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_j);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(222);
			k();
			setState(223);
			j_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class J_pContext extends ParserRuleContext {
		public TerminalNode SIM_STAR() { return getToken(PrevParser.SIM_STAR, 0); }
		public KContext k() {
			return getRuleContext(KContext.class,0);
		}
		public J_pContext j_p() {
			return getRuleContext(J_pContext.class,0);
		}
		public TerminalNode SIM_SLH() { return getToken(PrevParser.SIM_SLH, 0); }
		public TerminalNode SIM_PRCNT() { return getToken(PrevParser.SIM_PRCNT, 0); }
		public J_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_j_p; }
	}

	public final J_pContext j_p() throws RecognitionException {
		J_pContext _localctx = new J_pContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_j_p);
		try {
			setState(238);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(225);
				match(SIM_STAR);
				setState(226);
				k();
				setState(227);
				j_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(229);
				match(SIM_SLH);
				setState(230);
				k();
				setState(231);
				j_p();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(233);
				match(SIM_PRCNT);
				setState(234);
				k();
				setState(235);
				j_p();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class KContext extends ParserRuleContext {
		public TerminalNode SIM_EKSP() { return getToken(PrevParser.SIM_EKSP, 0); }
		public KContext k() {
			return getRuleContext(KContext.class,0);
		}
		public TerminalNode SIM_PLUS() { return getToken(PrevParser.SIM_PLUS, 0); }
		public TerminalNode SIM_MINUS() { return getToken(PrevParser.SIM_MINUS, 0); }
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public MContext m() {
			return getRuleContext(MContext.class,0);
		}
		public KContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_k; }
	}

	public final KContext k() throws RecognitionException {
		KContext _localctx = new KContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_k);
		try {
			setState(249);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_EKSP:
				enterOuterAlt(_localctx, 1);
				{
				setState(240);
				match(SIM_EKSP);
				setState(241);
				k();
				}
				break;
			case SIM_PLUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(242);
				match(SIM_PLUS);
				setState(243);
				k();
				}
				break;
			case SIM_MINUS:
				enterOuterAlt(_localctx, 3);
				{
				setState(244);
				match(SIM_MINUS);
				setState(245);
				k();
				}
				break;
			case SIM_TOP:
				enterOuterAlt(_localctx, 4);
				{
				setState(246);
				match(SIM_TOP);
				setState(247);
				k();
				}
				break;
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case KW_DEL:
			case KW_NEW:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 5);
				{
				setState(248);
				m();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MContext extends ParserRuleContext {
		public NContext n() {
			return getRuleContext(NContext.class,0);
		}
		public M_pContext m_p() {
			return getRuleContext(M_pContext.class,0);
		}
		public MContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_m; }
	}

	public final MContext m() throws RecognitionException {
		MContext _localctx = new MContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_m);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(251);
			n();
			setState(252);
			m_p();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class M_pContext extends ParserRuleContext {
		public TerminalNode SIM_LSQRBR() { return getToken(PrevParser.SIM_LSQRBR, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode SIM_RSQRBR() { return getToken(PrevParser.SIM_RSQRBR, 0); }
		public M_pContext m_p() {
			return getRuleContext(M_pContext.class,0);
		}
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public TerminalNode SIM_DOT() { return getToken(PrevParser.SIM_DOT, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public M_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_m_p; }
	}

	public final M_pContext m_p() throws RecognitionException {
		M_pContext _localctx = new M_pContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_m_p);
		try {
			setState(265);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(254);
				match(SIM_LSQRBR);
				setState(255);
				expr();
				setState(256);
				match(SIM_RSQRBR);
				setState(257);
				m_p();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(259);
				match(SIM_TOP);
				setState(260);
				m_p();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(261);
				match(SIM_DOT);
				setState(262);
				match(IDENTIFIER);
				setState(263);
				m_p();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NContext extends ParserRuleContext {
		public TerminalNode CONST_CHAR() { return getToken(PrevParser.CONST_CHAR, 0); }
		public TerminalNode CONST_STRING() { return getToken(PrevParser.CONST_STRING, 0); }
		public TerminalNode CONST_INTEGER() { return getToken(PrevParser.CONST_INTEGER, 0); }
		public TerminalNode CONST_LITERAL() { return getToken(PrevParser.CONST_LITERAL, 0); }
		public TerminalNode CONST_BOOLEAN() { return getToken(PrevParser.CONST_BOOLEAN, 0); }
		public TerminalNode CONST_VOID() { return getToken(PrevParser.CONST_VOID, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public N_pContext n_p() {
			return getRuleContext(N_pContext.class,0);
		}
		public TerminalNode KW_NEW() { return getToken(PrevParser.KW_NEW, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode KW_DEL() { return getToken(PrevParser.KW_DEL, 0); }
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public StmntContext stmnt() {
			return getRuleContext(StmntContext.class,0);
		}
		public TerminalNode SIM_SCOL() { return getToken(PrevParser.SIM_SCOL, 0); }
		public Stmnt_argsContext stmnt_args() {
			return getRuleContext(Stmnt_argsContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public N_ppContext n_pp() {
			return getRuleContext(N_ppContext.class,0);
		}
		public NContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_n; }
	}

	public final NContext n() throws RecognitionException {
		NContext _localctx = new NContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_n);
		try {
			setState(289);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(267);
				match(CONST_CHAR);
				}
				break;
			case CONST_STRING:
				enterOuterAlt(_localctx, 2);
				{
				setState(268);
				match(CONST_STRING);
				}
				break;
			case CONST_INTEGER:
				enterOuterAlt(_localctx, 3);
				{
				setState(269);
				match(CONST_INTEGER);
				}
				break;
			case CONST_LITERAL:
				enterOuterAlt(_localctx, 4);
				{
				setState(270);
				match(CONST_LITERAL);
				}
				break;
			case CONST_BOOLEAN:
				enterOuterAlt(_localctx, 5);
				{
				setState(271);
				match(CONST_BOOLEAN);
				}
				break;
			case CONST_VOID:
				enterOuterAlt(_localctx, 6);
				{
				setState(272);
				match(CONST_VOID);
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 7);
				{
				setState(273);
				match(IDENTIFIER);
				setState(274);
				n_p();
				}
				break;
			case KW_NEW:
				enterOuterAlt(_localctx, 8);
				{
				setState(275);
				match(KW_NEW);
				setState(276);
				expr();
				}
				break;
			case KW_DEL:
				enterOuterAlt(_localctx, 9);
				{
				setState(277);
				match(KW_DEL);
				setState(278);
				expr();
				}
				break;
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 10);
				{
				setState(279);
				match(SIM_LSQLBR);
				setState(280);
				stmnt();
				setState(281);
				match(SIM_SCOL);
				setState(282);
				stmnt_args();
				setState(283);
				match(SIM_RSQLBR);
				}
				break;
			case SIM_LPAR:
				enterOuterAlt(_localctx, 11);
				{
				setState(285);
				match(SIM_LPAR);
				setState(286);
				expr();
				setState(287);
				n_pp();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class N_pContext extends ParserRuleContext {
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Expr_argsContext expr_args() {
			return getRuleContext(Expr_argsContext.class,0);
		}
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public N_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_n_p; }
	}

	public final N_pContext n_p() throws RecognitionException {
		N_pContext _localctx = new N_pContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_n_p);
		try {
			setState(299);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(292);
				match(SIM_LPAR);
				setState(293);
				expr();
				setState(294);
				expr_args();
				setState(295);
				match(SIM_RPAR);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(297);
				match(SIM_LPAR);
				setState(298);
				match(SIM_RPAR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class N_ppContext extends ParserRuleContext {
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public N_ppContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_n_pp; }
	}

	public final N_ppContext n_pp() throws RecognitionException {
		N_ppContext _localctx = new N_ppContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_n_pp);
		try {
			setState(306);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COL:
				enterOuterAlt(_localctx, 1);
				{
				setState(301);
				match(SIM_COL);
				setState(302);
				type();
				setState(303);
				match(SIM_RPAR);
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(305);
				match(SIM_RPAR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expr_argsContext extends ParserRuleContext {
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Expr_argsContext expr_args() {
			return getRuleContext(Expr_argsContext.class,0);
		}
		public Expr_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr_args; }
	}

	public final Expr_argsContext expr_args() throws RecognitionException {
		Expr_argsContext _localctx = new Expr_argsContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_expr_args);
		try {
			setState(313);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(308);
				match(SIM_COM);
				setState(309);
				expr();
				setState(310);
				expr_args();
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Stmnt_argsContext extends ParserRuleContext {
		public StmntContext stmnt() {
			return getRuleContext(StmntContext.class,0);
		}
		public TerminalNode SIM_SCOL() { return getToken(PrevParser.SIM_SCOL, 0); }
		public Stmnt_argsContext stmnt_args() {
			return getRuleContext(Stmnt_argsContext.class,0);
		}
		public Stmnt_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stmnt_args; }
	}

	public final Stmnt_argsContext stmnt_args() throws RecognitionException {
		Stmnt_argsContext _localctx = new Stmnt_argsContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_stmnt_args);
		try {
			setState(320);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case KW_DEL:
			case KW_IF:
			case KW_NEW:
			case KW_WHILE:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
			case SIM_EKSP:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_TOP:
				enterOuterAlt(_localctx, 1);
				{
				setState(315);
				stmnt();
				setState(316);
				match(SIM_SCOL);
				setState(317);
				stmnt_args();
				}
				break;
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StmntContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Stmnt_pContext stmnt_p() {
			return getRuleContext(Stmnt_pContext.class,0);
		}
		public TerminalNode KW_IF() { return getToken(PrevParser.KW_IF, 0); }
		public TerminalNode KW_THEN() { return getToken(PrevParser.KW_THEN, 0); }
		public List<StmntContext> stmnt() {
			return getRuleContexts(StmntContext.class);
		}
		public StmntContext stmnt(int i) {
			return getRuleContext(StmntContext.class,i);
		}
		public TerminalNode KW_ELSE() { return getToken(PrevParser.KW_ELSE, 0); }
		public TerminalNode KW_WHILE() { return getToken(PrevParser.KW_WHILE, 0); }
		public TerminalNode KW_DO() { return getToken(PrevParser.KW_DO, 0); }
		public StmntContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stmnt; }
	}

	public final StmntContext stmnt() throws RecognitionException {
		StmntContext _localctx = new StmntContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_stmnt);
		try {
			setState(337);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case KW_DEL:
			case KW_NEW:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
			case SIM_EKSP:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_TOP:
				enterOuterAlt(_localctx, 1);
				{
				setState(322);
				expr();
				setState(323);
				stmnt_p();
				}
				break;
			case KW_IF:
				enterOuterAlt(_localctx, 2);
				{
				setState(325);
				match(KW_IF);
				setState(326);
				expr();
				setState(327);
				match(KW_THEN);
				setState(328);
				stmnt();
				setState(329);
				match(KW_ELSE);
				setState(330);
				stmnt();
				}
				break;
			case KW_WHILE:
				enterOuterAlt(_localctx, 3);
				{
				setState(332);
				match(KW_WHILE);
				setState(333);
				expr();
				setState(334);
				match(KW_DO);
				setState(335);
				stmnt();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Stmnt_pContext extends ParserRuleContext {
		public TerminalNode SIM_IS() { return getToken(PrevParser.SIM_IS, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Stmnt_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stmnt_p; }
	}

	public final Stmnt_pContext stmnt_p() throws RecognitionException {
		Stmnt_pContext _localctx = new Stmnt_pContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_stmnt_p);
		try {
			setState(342);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_ELSE:
			case SIM_SCOL:
				enterOuterAlt(_localctx, 1);
				{
				}
				break;
			case SIM_IS:
				enterOuterAlt(_localctx, 2);
				{
				setState(340);
				match(SIM_IS);
				setState(341);
				expr();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\66\u015b\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\3\2\3\2\3"+
		"\2\3\2\3\3\3\3\3\3\3\3\5\3G\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\5\4U\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3"+
		"\5\3\5\3\5\3\5\5\5g\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6p\n\6\3\7\3\7\3"+
		"\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7\u008d\n\7\3\b\3\b\3\b\3\b\3\b\3\b\5\b"+
		"\u0095\n\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t\u009e\n\t\3\n\3\n\3\n\3\13"+
		"\3\13\3\13\3\13\3\13\3\13\3\13\3\13\5\13\u00ab\n\13\3\f\3\f\3\f\3\r\3"+
		"\r\3\r\3\r\3\r\5\r\u00b5\n\r\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\5"+
		"\17\u00bf\n\17\3\20\3\20\3\20\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\5\21\u00d1\n\21\3\22\3\22\3\22\3\23\3\23\3\23"+
		"\3\23\3\23\3\23\3\23\3\23\3\23\5\23\u00df\n\23\3\24\3\24\3\24\3\25\3\25"+
		"\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\5\25\u00f1\n\25"+
		"\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u00fc\n\26\3\27\3\27"+
		"\3\27\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\5\30\u010c"+
		"\n\30\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31"+
		"\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\5\31\u0124\n\31\3\32\3\32"+
		"\3\32\3\32\3\32\3\32\3\32\3\32\5\32\u012e\n\32\3\33\3\33\3\33\3\33\3\33"+
		"\5\33\u0135\n\33\3\34\3\34\3\34\3\34\3\34\5\34\u013c\n\34\3\35\3\35\3"+
		"\35\3\35\3\35\5\35\u0143\n\35\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36"+
		"\3\36\3\36\3\36\3\36\3\36\3\36\3\36\5\36\u0154\n\36\3\37\3\37\3\37\5\37"+
		"\u0159\n\37\3\37\2\2 \2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,."+
		"\60\62\64\668:<\2\2\2\u0171\2>\3\2\2\2\4F\3\2\2\2\6T\3\2\2\2\bf\3\2\2"+
		"\2\no\3\2\2\2\f\u008c\3\2\2\2\16\u0094\3\2\2\2\20\u009d\3\2\2\2\22\u009f"+
		"\3\2\2\2\24\u00aa\3\2\2\2\26\u00ac\3\2\2\2\30\u00b4\3\2\2\2\32\u00b6\3"+
		"\2\2\2\34\u00be\3\2\2\2\36\u00c0\3\2\2\2 \u00d0\3\2\2\2\"\u00d2\3\2\2"+
		"\2$\u00de\3\2\2\2&\u00e0\3\2\2\2(\u00f0\3\2\2\2*\u00fb\3\2\2\2,\u00fd"+
		"\3\2\2\2.\u010b\3\2\2\2\60\u0123\3\2\2\2\62\u012d\3\2\2\2\64\u0134\3\2"+
		"\2\2\66\u013b\3\2\2\28\u0142\3\2\2\2:\u0153\3\2\2\2<\u0158\3\2\2\2>?\5"+
		"\6\4\2?@\5\4\3\2@A\7\2\2\3A\3\3\2\2\2BC\5\6\4\2CD\5\4\3\2DG\3\2\2\2EG"+
		"\3\2\2\2FB\3\2\2\2FE\3\2\2\2G\5\3\2\2\2HI\7\22\2\2IJ\7\31\2\2JK\7\63\2"+
		"\2KU\5\f\7\2LM\7\23\2\2MN\7\31\2\2NO\7\"\2\2OU\5\f\7\2PQ\7\r\2\2QR\7\31"+
		"\2\2RS\7\32\2\2SU\5\b\5\2TH\3\2\2\2TL\3\2\2\2TP\3\2\2\2U\7\3\2\2\2VW\7"+
		"\33\2\2WX\7\"\2\2XY\5\f\7\2YZ\7\63\2\2Z[\5\22\n\2[g\3\2\2\2\\]\7\31\2"+
		"\2]^\7\"\2\2^_\5\f\7\2_`\5\n\6\2`a\7\33\2\2ab\7\"\2\2bc\5\f\7\2cd\7\63"+
		"\2\2de\5\22\n\2eg\3\2\2\2fV\3\2\2\2f\\\3\2\2\2g\t\3\2\2\2hi\7!\2\2ij\7"+
		"\31\2\2jk\7\"\2\2kl\5\f\7\2lm\5\n\6\2mp\3\2\2\2np\3\2\2\2oh\3\2\2\2on"+
		"\3\2\2\2p\13\3\2\2\2qr\7\b\2\2r\u008d\5\16\b\2st\7\t\2\2t\u008d\5\16\b"+
		"\2uv\7\17\2\2v\u008d\5\16\b\2wx\7\24\2\2x\u008d\5\16\b\2yz\7\31\2\2z\u008d"+
		"\5\16\b\2{|\7\62\2\2|}\5\f\7\2}~\5\16\b\2~\u008d\3\2\2\2\177\u0080\7\34"+
		"\2\2\u0080\u0081\7\31\2\2\u0081\u0082\7\"\2\2\u0082\u0083\5\f\7\2\u0083"+
		"\u0084\5\20\t\2\u0084\u0085\7\35\2\2\u0085\u0086\5\16\b\2\u0086\u008d"+
		"\3\2\2\2\u0087\u0088\7\32\2\2\u0088\u0089\5\f\7\2\u0089\u008a\7\33\2\2"+
		"\u008a\u008b\5\16\b\2\u008b\u008d\3\2\2\2\u008cq\3\2\2\2\u008cs\3\2\2"+
		"\2\u008cu\3\2\2\2\u008cw\3\2\2\2\u008cy\3\2\2\2\u008c{\3\2\2\2\u008c\177"+
		"\3\2\2\2\u008c\u0087\3\2\2\2\u008d\r\3\2\2\2\u008e\u008f\7\36\2\2\u008f"+
		"\u0090\5\22\n\2\u0090\u0091\7\37\2\2\u0091\u0092\5\16\b\2\u0092\u0095"+
		"\3\2\2\2\u0093\u0095\3\2\2\2\u0094\u008e\3\2\2\2\u0094\u0093\3\2\2\2\u0095"+
		"\17\3\2\2\2\u0096\u0097\7!\2\2\u0097\u0098\7\31\2\2\u0098\u0099\7\"\2"+
		"\2\u0099\u009a\5\f\7\2\u009a\u009b\5\20\t\2\u009b\u009e\3\2\2\2\u009c"+
		"\u009e\3\2\2\2\u009d\u0096\3\2\2\2\u009d\u009c\3\2\2\2\u009e\21\3\2\2"+
		"\2\u009f\u00a0\5\26\f\2\u00a0\u00a1\5\24\13\2\u00a1\23\3\2\2\2\u00a2\u00a3"+
		"\7\25\2\2\u00a3\u00a4\7\34\2\2\u00a4\u00a5\5\6\4\2\u00a5\u00a6\5\4\3\2"+
		"\u00a6\u00a7\7\35\2\2\u00a7\u00a8\5\24\13\2\u00a8\u00ab\3\2\2\2\u00a9"+
		"\u00ab\3\2\2\2\u00aa\u00a2\3\2\2\2\u00aa\u00a9\3\2\2\2\u00ab\25\3\2\2"+
		"\2\u00ac\u00ad\5\32\16\2\u00ad\u00ae\5\30\r\2\u00ae\27\3\2\2\2\u00af\u00b0"+
		"\7%\2\2\u00b0\u00b1\5\32\16\2\u00b1\u00b2\5\30\r\2\u00b2\u00b5\3\2\2\2"+
		"\u00b3\u00b5\3\2\2\2\u00b4\u00af\3\2\2\2\u00b4\u00b3\3\2\2\2\u00b5\31"+
		"\3\2\2\2\u00b6\u00b7\5\36\20\2\u00b7\u00b8\5\34\17\2\u00b8\33\3\2\2\2"+
		"\u00b9\u00ba\7$\2\2\u00ba\u00bb\5\36\20\2\u00bb\u00bc\5\34\17\2\u00bc"+
		"\u00bf\3\2\2\2\u00bd\u00bf\3\2\2\2\u00be\u00b9\3\2\2\2\u00be\u00bd\3\2"+
		"\2\2\u00bf\35\3\2\2\2\u00c0\u00c1\5\"\22\2\u00c1\u00c2\5 \21\2\u00c2\37"+
		"\3\2\2\2\u00c3\u00c4\7\'\2\2\u00c4\u00d1\5\"\22\2\u00c5\u00c6\7(\2\2\u00c6"+
		"\u00d1\5\"\22\2\u00c7\u00c8\7)\2\2\u00c8\u00d1\5\"\22\2\u00c9\u00ca\7"+
		"*\2\2\u00ca\u00d1\5\"\22\2\u00cb\u00cc\7+\2\2\u00cc\u00d1\5\"\22\2\u00cd"+
		"\u00ce\7,\2\2\u00ce\u00d1\5\"\22\2\u00cf\u00d1\3\2\2\2\u00d0\u00c3\3\2"+
		"\2\2\u00d0\u00c5\3\2\2\2\u00d0\u00c7\3\2\2\2\u00d0\u00c9\3\2\2\2\u00d0"+
		"\u00cb\3\2\2\2\u00d0\u00cd\3\2\2\2\u00d0\u00cf\3\2\2\2\u00d1!\3\2\2\2"+
		"\u00d2\u00d3\5&\24\2\u00d3\u00d4\5$\23\2\u00d4#\3\2\2\2\u00d5\u00d6\7"+
		"\60\2\2\u00d6\u00d7\5&\24\2\u00d7\u00d8\5$\23\2\u00d8\u00df\3\2\2\2\u00d9"+
		"\u00da\7\61\2\2\u00da\u00db\5&\24\2\u00db\u00dc\5$\23\2\u00dc\u00df\3"+
		"\2\2\2\u00dd\u00df\3\2\2\2\u00de\u00d5\3\2\2\2\u00de\u00d9\3\2\2\2\u00de"+
		"\u00dd\3\2\2\2\u00df%\3\2\2\2\u00e0\u00e1\5*\26\2\u00e1\u00e2\5(\25\2"+
		"\u00e2\'\3\2\2\2\u00e3\u00e4\7-\2\2\u00e4\u00e5\5*\26\2\u00e5\u00e6\5"+
		"(\25\2\u00e6\u00f1\3\2\2\2\u00e7\u00e8\7.\2\2\u00e8\u00e9\5*\26\2\u00e9"+
		"\u00ea\5(\25\2\u00ea\u00f1\3\2\2\2\u00eb\u00ec\7/\2\2\u00ec\u00ed\5*\26"+
		"\2\u00ed\u00ee\5(\25\2\u00ee\u00f1\3\2\2\2\u00ef\u00f1\3\2\2\2\u00f0\u00e3"+
		"\3\2\2\2\u00f0\u00e7\3\2\2\2\u00f0\u00eb\3\2\2\2\u00f0\u00ef\3\2\2\2\u00f1"+
		")\3\2\2\2\u00f2\u00f3\7&\2\2\u00f3\u00fc\5*\26\2\u00f4\u00f5\7\60\2\2"+
		"\u00f5\u00fc\5*\26\2\u00f6\u00f7\7\61\2\2\u00f7\u00fc\5*\26\2\u00f8\u00f9"+
		"\7\62\2\2\u00f9\u00fc\5*\26\2\u00fa\u00fc\5,\27\2\u00fb\u00f2\3\2\2\2"+
		"\u00fb\u00f4\3\2\2\2\u00fb\u00f6\3\2\2\2\u00fb\u00f8\3\2\2\2\u00fb\u00fa"+
		"\3\2\2\2\u00fc+\3\2\2\2\u00fd\u00fe\5\60\31\2\u00fe\u00ff\5.\30\2\u00ff"+
		"-\3\2\2\2\u0100\u0101\7\36\2\2\u0101\u0102\5\22\n\2\u0102\u0103\7\37\2"+
		"\2\u0103\u0104\5.\30\2\u0104\u010c\3\2\2\2\u0105\u0106\7\62\2\2\u0106"+
		"\u010c\5.\30\2\u0107\u0108\7 \2\2\u0108\u0109\7\31\2\2\u0109\u010c\5."+
		"\30\2\u010a\u010c\3\2\2\2\u010b\u0100\3\2\2\2\u010b\u0105\3\2\2\2\u010b"+
		"\u0107\3\2\2\2\u010b\u010a\3\2\2\2\u010c/\3\2\2\2\u010d\u0124\7\4\2\2"+
		"\u010e\u0124\7\5\2\2\u010f\u0124\7\6\2\2\u0110\u0124\7\7\2\2\u0111\u0124"+
		"\7\27\2\2\u0112\u0124\7\30\2\2\u0113\u0114\7\31\2\2\u0114\u0124\5\62\32"+
		"\2\u0115\u0116\7\20\2\2\u0116\u0124\5\22\n\2\u0117\u0118\7\n\2\2\u0118"+
		"\u0124\5\22\n\2\u0119\u011a\7\34\2\2\u011a\u011b\5:\36\2\u011b\u011c\7"+
		"#\2\2\u011c\u011d\58\35\2\u011d\u011e\7\35\2\2\u011e\u0124\3\2\2\2\u011f"+
		"\u0120\7\32\2\2\u0120\u0121\5\22\n\2\u0121\u0122\5\64\33\2\u0122\u0124"+
		"\3\2\2\2\u0123\u010d\3\2\2\2\u0123\u010e\3\2\2\2\u0123\u010f\3\2\2\2\u0123"+
		"\u0110\3\2\2\2\u0123\u0111\3\2\2\2\u0123\u0112\3\2\2\2\u0123\u0113\3\2"+
		"\2\2\u0123\u0115\3\2\2\2\u0123\u0117\3\2\2\2\u0123\u0119\3\2\2\2\u0123"+
		"\u011f\3\2\2\2\u0124\61\3\2\2\2\u0125\u012e\3\2\2\2\u0126\u0127\7\32\2"+
		"\2\u0127\u0128\5\22\n\2\u0128\u0129\5\66\34\2\u0129\u012a\7\33\2\2\u012a"+
		"\u012e\3\2\2\2\u012b\u012c\7\32\2\2\u012c\u012e\7\33\2\2\u012d\u0125\3"+
		"\2\2\2\u012d\u0126\3\2\2\2\u012d\u012b\3\2\2\2\u012e\63\3\2\2\2\u012f"+
		"\u0130\7\"\2\2\u0130\u0131\5\f\7\2\u0131\u0132\7\33\2\2\u0132\u0135\3"+
		"\2\2\2\u0133\u0135\7\33\2\2\u0134\u012f\3\2\2\2\u0134\u0133\3\2\2\2\u0135"+
		"\65\3\2\2\2\u0136\u0137\7!\2\2\u0137\u0138\5\22\n\2\u0138\u0139\5\66\34"+
		"\2\u0139\u013c\3\2\2\2\u013a\u013c\3\2\2\2\u013b\u0136\3\2\2\2\u013b\u013a"+
		"\3\2\2\2\u013c\67\3\2\2\2\u013d\u013e\5:\36\2\u013e\u013f\7#\2\2\u013f"+
		"\u0140\58\35\2\u0140\u0143\3\2\2\2\u0141\u0143\3\2\2\2\u0142\u013d\3\2"+
		"\2\2\u0142\u0141\3\2\2\2\u01439\3\2\2\2\u0144\u0145\5\22\n\2\u0145\u0146"+
		"\5<\37\2\u0146\u0154\3\2\2\2\u0147\u0148\7\16\2\2\u0148\u0149\5\22\n\2"+
		"\u0149\u014a\7\21\2\2\u014a\u014b\5:\36\2\u014b\u014c\7\f\2\2\u014c\u014d"+
		"\5:\36\2\u014d\u0154\3\2\2\2\u014e\u014f\7\26\2\2\u014f\u0150\5\22\n\2"+
		"\u0150\u0151\7\13\2\2\u0151\u0152\5:\36\2\u0152\u0154\3\2\2\2\u0153\u0144"+
		"\3\2\2\2\u0153\u0147\3\2\2\2\u0153\u014e\3\2\2\2\u0154;\3\2\2\2\u0155"+
		"\u0159\3\2\2\2\u0156\u0157\7\63\2\2\u0157\u0159\5\22\n\2\u0158\u0155\3"+
		"\2\2\2\u0158\u0156\3\2\2\2\u0159=\3\2\2\2\30FTfo\u008c\u0094\u009d\u00aa"+
		"\u00b4\u00be\u00d0\u00de\u00f0\u00fb\u010b\u0123\u012d\u0134\u013b\u0142"+
		"\u0153\u0158";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}