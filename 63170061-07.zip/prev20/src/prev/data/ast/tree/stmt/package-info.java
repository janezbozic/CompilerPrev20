/**
 * Abstract syntax tree: representing statements.
 */
package prev.data.ast.tree.stmt;
