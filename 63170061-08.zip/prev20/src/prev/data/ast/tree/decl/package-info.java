/**
 * Abstract syntax tree: representing declarations.
 */
package prev.data.ast.tree.decl;
