package prev.data.imc.code.expr;

import prev.data.imc.code.*;

/**
 * Intermediate code instruction denoting an expression.
 */
public abstract class ImcExpr extends ImcInstr {
}
