/**
 * Visitors for traversing intermediate code trees.
 */
package prev.data.imc.visitor;
