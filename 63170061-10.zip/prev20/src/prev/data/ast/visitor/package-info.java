/**
 * Abstract syntax tree visitor.
 */
package prev.data.ast.visitor;
