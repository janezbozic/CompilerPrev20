/**
 * Liveness analysis.
 */
package prev.phase.livean;