// Generated from synan/PrevParser.g4 by ANTLR 4.8


	package prev.phase.synan;
	
	import java.util.*;
	
	import prev.common.report.*;
	import prev.phase.lexan.*;

	import prev.data.ast.tree.decl.*;
    import prev.data.ast.tree.expr.*;
    import prev.data.ast.tree.stmt.*;
    import prev.data.ast.tree.type.*;
    import prev.data.ast.tree.*;

	import prev.phase.lexan.LexAn.PrevToken;


import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PrevParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		COMMENT=1, CONST_CHAR=2, CONST_STRING=3, CONST_INTEGER=4, CONST_LITERAL=5, 
		KW_BOOLEAN=6, KW_CHAR=7, KW_DEL=8, KW_DO=9, KW_ELSE=10, KW_FUN=11, KW_IF=12, 
		KW_INTEGER=13, KW_NEW=14, KW_THEN=15, KW_TYP=16, KW_VAR=17, KW_VOID=18, 
		KW_WHERE=19, KW_WHILE=20, CONST_BOOLEAN=21, CONST_VOID=22, IDENTIFIER=23, 
		SIM_LPAR=24, SIM_RPAR=25, SIM_LSQLBR=26, SIM_RSQLBR=27, SIM_LSQRBR=28, 
		SIM_RSQRBR=29, SIM_DOT=30, SIM_COM=31, SIM_COL=32, SIM_SCOL=33, SIM_AND=34, 
		SIM_LINE=35, SIM_EKSP=36, SIM_EQU=37, SIM_NEQU=38, SIM_LT=39, SIM_GT=40, 
		SIM_LTEQU=41, SIM_GTEQU=42, SIM_STAR=43, SIM_SLH=44, SIM_PRCNT=45, SIM_PLUS=46, 
		SIM_MINUS=47, SIM_TOP=48, SIM_IS=49, SPACE=50, TAB=51, ERROR=52;
	public static final int
		RULE_source = 0, RULE_source_p = 1, RULE_decl = 2, RULE_decl_p = 3, RULE_decl_args = 4, 
		RULE_type = 5, RULE_type_args = 6, RULE_declaration_binder = 7, RULE_declaration_binder_p = 8, 
		RULE_disjunctive = 9, RULE_disjunctive_p = 10, RULE_conjunctive = 11, 
		RULE_conjunctive_p = 12, RULE_relational = 13, RULE_relational_p = 14, 
		RULE_additive = 15, RULE_additive_p = 16, RULE_multiplicative = 17, RULE_multiplicative_p = 18, 
		RULE_prefix = 19, RULE_postfix = 20, RULE_postfix_p = 21, RULE_expr = 22, 
		RULE_expr_p = 23, RULE_expr_pp = 24, RULE_expr_args = 25, RULE_stmnt_args = 26, 
		RULE_stmnt = 27, RULE_stmnt_p = 28;
	private static String[] makeRuleNames() {
		return new String[] {
			"source", "source_p", "decl", "decl_p", "decl_args", "type", "type_args", 
			"declaration_binder", "declaration_binder_p", "disjunctive", "disjunctive_p", 
			"conjunctive", "conjunctive_p", "relational", "relational_p", "additive", 
			"additive_p", "multiplicative", "multiplicative_p", "prefix", "postfix", 
			"postfix_p", "expr", "expr_p", "expr_pp", "expr_args", "stmnt_args", 
			"stmnt", "stmnt_p"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, "'nil'", "'boolean'", "'char'", "'del'", 
			"'do'", "'else'", "'fun'", "'if'", "'integer'", "'new'", "'then'", "'typ'", 
			"'var'", "'void'", "'where'", "'while'", null, "'none'", null, "'('", 
			"')'", "'{'", "'}'", "'['", "']'", "'.'", "','", "':'", "';'", "'&'", 
			"'|'", "'!'", "'=='", "'!='", "'<'", "'>'", "'<='", "'>='", "'*'", "'/'", 
			"'%'", "'+'", "'-'", "'^'", "'='"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "COMMENT", "CONST_CHAR", "CONST_STRING", "CONST_INTEGER", "CONST_LITERAL", 
			"KW_BOOLEAN", "KW_CHAR", "KW_DEL", "KW_DO", "KW_ELSE", "KW_FUN", "KW_IF", 
			"KW_INTEGER", "KW_NEW", "KW_THEN", "KW_TYP", "KW_VAR", "KW_VOID", "KW_WHERE", 
			"KW_WHILE", "CONST_BOOLEAN", "CONST_VOID", "IDENTIFIER", "SIM_LPAR", 
			"SIM_RPAR", "SIM_LSQLBR", "SIM_RSQLBR", "SIM_LSQRBR", "SIM_RSQRBR", "SIM_DOT", 
			"SIM_COM", "SIM_COL", "SIM_SCOL", "SIM_AND", "SIM_LINE", "SIM_EKSP", 
			"SIM_EQU", "SIM_NEQU", "SIM_LT", "SIM_GT", "SIM_LTEQU", "SIM_GTEQU", 
			"SIM_STAR", "SIM_SLH", "SIM_PRCNT", "SIM_PLUS", "SIM_MINUS", "SIM_TOP", 
			"SIM_IS", "SPACE", "TAB", "ERROR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "PrevParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public PrevParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class SourceContext extends ParserRuleContext {
		public AstTrees <AstDecl> ast;
		public DeclContext decl;
		public Source_pContext source_p;
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public TerminalNode EOF() { return getToken(PrevParser.EOF, 0); }
		public SourceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_source; }
	}

	public final SourceContext source() throws RecognitionException {
		SourceContext _localctx = new SourceContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_source);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(58);
			((SourceContext)_localctx).decl = decl();
			setState(59);
			((SourceContext)_localctx).source_p = source_p();
			setState(60);
			match(EOF);

					Vector <AstDecl> ds = new Vector <AstDecl>();
					ds.add(((SourceContext)_localctx).decl.ast);
					ds.addAll(((SourceContext)_localctx).source_p.ast);
					((SourceContext)_localctx).ast =  new AstTrees<AstDecl>(ds);
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Source_pContext extends ParserRuleContext {
		public Vector <AstDecl> ast;
		public DeclContext decl;
		public Source_pContext source_p;
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public Source_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_source_p; }
	}

	public final Source_pContext source_p() throws RecognitionException {
		Source_pContext _localctx = new Source_pContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_source_p);
		try {
			setState(68);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_FUN:
			case KW_TYP:
			case KW_VAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(63);
				((Source_pContext)_localctx).decl = decl();
				setState(64);
				((Source_pContext)_localctx).source_p = source_p();

						Vector <AstDecl> ds = new Vector <AstDecl>();
						ds.add(((Source_pContext)_localctx).decl.ast);
						ds.addAll(((Source_pContext)_localctx).source_p.ast);
						((Source_pContext)_localctx).ast =  ds;
					
				}
				break;
			case EOF:
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{

						((Source_pContext)_localctx).ast =  new Vector<AstDecl>();
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclContext extends ParserRuleContext {
		public AstDecl ast;
		public Token KW_TYP;
		public Token IDENTIFIER;
		public TypeContext type;
		public Token KW_VAR;
		public Token KW_FUN;
		public Decl_pContext decl_p;
		public Declaration_binderContext declaration_binder;
		public TerminalNode KW_TYP() { return getToken(PrevParser.KW_TYP, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_IS() { return getToken(PrevParser.SIM_IS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode KW_VAR() { return getToken(PrevParser.KW_VAR, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TerminalNode KW_FUN() { return getToken(PrevParser.KW_FUN, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public Decl_pContext decl_p() {
			return getRuleContext(Decl_pContext.class,0);
		}
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public DeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl; }
	}

	public final DeclContext decl() throws RecognitionException {
		DeclContext _localctx = new DeclContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_decl);
		try {
			setState(93);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_TYP:
				enterOuterAlt(_localctx, 1);
				{
				setState(70);
				((DeclContext)_localctx).KW_TYP = match(KW_TYP);
				setState(71);
				((DeclContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(72);
				match(SIM_IS);
				setState(73);
				((DeclContext)_localctx).type = type();

						((DeclContext)_localctx).ast =  new AstTypeDecl(new Location((PrevToken)((DeclContext)_localctx).KW_TYP, ((DeclContext)_localctx).type.ast), (((DeclContext)_localctx).IDENTIFIER!=null?((DeclContext)_localctx).IDENTIFIER.getText():null), ((DeclContext)_localctx).type.ast);
					
				}
				break;
			case KW_VAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(76);
				((DeclContext)_localctx).KW_VAR = match(KW_VAR);
				setState(77);
				((DeclContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(78);
				match(SIM_COL);
				setState(79);
				((DeclContext)_localctx).type = type();

						((DeclContext)_localctx).ast =  new AstVarDecl(new Location((PrevToken)((DeclContext)_localctx).KW_VAR, ((DeclContext)_localctx).type.ast), (((DeclContext)_localctx).IDENTIFIER!=null?((DeclContext)_localctx).IDENTIFIER.getText():null), ((DeclContext)_localctx).type.ast);
					
				}
				break;
			case KW_FUN:
				enterOuterAlt(_localctx, 3);
				{
				setState(82);
				((DeclContext)_localctx).KW_FUN = match(KW_FUN);
				setState(83);
				((DeclContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(84);
				match(SIM_LPAR);
				setState(85);
				((DeclContext)_localctx).decl_p = decl_p();
				setState(86);
				match(SIM_RPAR);
				setState(87);
				match(SIM_COL);
				setState(88);
				((DeclContext)_localctx).type = type();
				setState(89);
				match(SIM_IS);
				setState(90);
				((DeclContext)_localctx).declaration_binder = declaration_binder();

						((DeclContext)_localctx).ast =  new AstFunDecl(new Location((PrevToken)((DeclContext)_localctx).KW_FUN, ((DeclContext)_localctx).declaration_binder.ast), (((DeclContext)_localctx).IDENTIFIER!=null?((DeclContext)_localctx).IDENTIFIER.getText():null), ((DeclContext)_localctx).decl_p.ast, ((DeclContext)_localctx).type.ast, ((DeclContext)_localctx).declaration_binder.ast);
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Decl_pContext extends ParserRuleContext {
		public AstTrees <AstParDecl> ast;
		public Token IDENTIFIER;
		public TypeContext type;
		public Decl_argsContext decl_args;
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Decl_argsContext decl_args() {
			return getRuleContext(Decl_argsContext.class,0);
		}
		public Decl_pContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_p; }
	}

	public final Decl_pContext decl_p() throws RecognitionException {
		Decl_pContext _localctx = new Decl_pContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_decl_p);
		try {
			setState(102);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_RPAR:
				enterOuterAlt(_localctx, 1);
				{

						((Decl_pContext)_localctx).ast =  new AstTrees <AstParDecl> () ;
					
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(96);
				((Decl_pContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(97);
				match(SIM_COL);
				setState(98);
				((Decl_pContext)_localctx).type = type();
				setState(99);
				((Decl_pContext)_localctx).decl_args = decl_args();

						Vector <AstParDecl> da = new Vector <AstParDecl>();
						da.add(new AstParDecl(new Location((PrevToken)((Decl_pContext)_localctx).IDENTIFIER, ((Decl_pContext)_localctx).type.ast),(((Decl_pContext)_localctx).IDENTIFIER!=null?((Decl_pContext)_localctx).IDENTIFIER.getText():null), ((Decl_pContext)_localctx).type.ast));
						da.addAll(((Decl_pContext)_localctx).decl_args.ast);
						((Decl_pContext)_localctx).ast =  new AstTrees<AstParDecl>(da);
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Decl_argsContext extends ParserRuleContext {
		public Vector <AstParDecl> ast;
		public Token IDENTIFIER;
		public TypeContext type;
		public Decl_argsContext decl_args;
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Decl_argsContext decl_args() {
			return getRuleContext(Decl_argsContext.class,0);
		}
		public Decl_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_args; }
	}

	public final Decl_argsContext decl_args() throws RecognitionException {
		Decl_argsContext _localctx = new Decl_argsContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_decl_args);
		try {
			setState(112);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(104);
				match(SIM_COM);
				setState(105);
				((Decl_argsContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(106);
				match(SIM_COL);
				setState(107);
				((Decl_argsContext)_localctx).type = type();
				setState(108);
				((Decl_argsContext)_localctx).decl_args = decl_args();

						Vector <AstParDecl> da = new Vector <AstParDecl>();
						da.add(new AstParDecl(new Location((PrevToken)((Decl_argsContext)_localctx).IDENTIFIER, ((Decl_argsContext)_localctx).type.ast), (((Decl_argsContext)_localctx).IDENTIFIER!=null?((Decl_argsContext)_localctx).IDENTIFIER.getText():null), ((Decl_argsContext)_localctx).type.ast));
						da.addAll(((Decl_argsContext)_localctx).decl_args.ast);
						((Decl_argsContext)_localctx).ast =  da;
					
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{

						((Decl_argsContext)_localctx).ast =  new Vector <AstParDecl> () ;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public AstType ast;
		public Token KW_BOOLEAN;
		public Token KW_CHAR;
		public Token KW_INTEGER;
		public Token KW_VOID;
		public Token IDENTIFIER;
		public Token SIM_TOP;
		public TypeContext type;
		public Token SIM_LSQLBR;
		public Type_argsContext type_args;
		public Token SIM_RSQLBR;
		public Token SIM_LSQRBR;
		public Declaration_binderContext declaration_binder;
		public Token SIM_RSQRBR;
		public TerminalNode KW_BOOLEAN() { return getToken(PrevParser.KW_BOOLEAN, 0); }
		public TerminalNode KW_CHAR() { return getToken(PrevParser.KW_CHAR, 0); }
		public TerminalNode KW_INTEGER() { return getToken(PrevParser.KW_INTEGER, 0); }
		public TerminalNode KW_VOID() { return getToken(PrevParser.KW_VOID, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public Type_argsContext type_args() {
			return getRuleContext(Type_argsContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public TerminalNode SIM_LSQRBR() { return getToken(PrevParser.SIM_LSQRBR, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public TerminalNode SIM_RSQRBR() { return getToken(PrevParser.SIM_RSQRBR, 0); }
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_type);
		try {
			setState(156);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_BOOLEAN:
				enterOuterAlt(_localctx, 1);
				{
				setState(114);
				((TypeContext)_localctx).KW_BOOLEAN = match(KW_BOOLEAN);
				 AstType t = new AstAtomType(new Location((PrevToken)((TypeContext)_localctx).KW_BOOLEAN), AstAtomType.Type.BOOLEAN); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case KW_CHAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(117);
				((TypeContext)_localctx).KW_CHAR = match(KW_CHAR);
				 AstType t = new AstAtomType(new Location((PrevToken)((TypeContext)_localctx).KW_CHAR), AstAtomType.Type.CHAR); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case KW_INTEGER:
				enterOuterAlt(_localctx, 3);
				{
				setState(120);
				((TypeContext)_localctx).KW_INTEGER = match(KW_INTEGER);
				 AstType t = new AstAtomType(new Location((PrevToken)((TypeContext)_localctx).KW_INTEGER), AstAtomType.Type.INTEGER); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case KW_VOID:
				enterOuterAlt(_localctx, 4);
				{
				setState(123);
				((TypeContext)_localctx).KW_VOID = match(KW_VOID);
				 AstType t = new AstAtomType(new Location((PrevToken)((TypeContext)_localctx).KW_VOID), AstAtomType.Type.VOID); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 5);
				{
				setState(126);
				((TypeContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				 AstType t = new AstNameType(new Location((PrevToken)((TypeContext)_localctx).IDENTIFIER), (((TypeContext)_localctx).IDENTIFIER!=null?((TypeContext)_localctx).IDENTIFIER.getText():null)); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case SIM_TOP:
				enterOuterAlt(_localctx, 6);
				{
				setState(129);
				((TypeContext)_localctx).SIM_TOP = match(SIM_TOP);
				setState(130);
				((TypeContext)_localctx).type = type();
				 AstPtrType t = new AstPtrType (new Location((PrevToken)((TypeContext)_localctx).SIM_TOP, ((TypeContext)_localctx).type.ast), ((TypeContext)_localctx).type.ast); 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 7);
				{
				setState(134);
				((TypeContext)_localctx).SIM_LSQLBR = match(SIM_LSQLBR);
				setState(135);
				((TypeContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(136);
				match(SIM_COL);
				setState(137);
				((TypeContext)_localctx).type = type();
				setState(138);
				((TypeContext)_localctx).type_args = type_args();
				setState(139);
				((TypeContext)_localctx).SIM_RSQLBR = match(SIM_RSQLBR);

						Vector v = new Vector<AstCompDecl>();
						AstCompDecl c = new AstCompDecl(new Location((PrevToken)((TypeContext)_localctx).IDENTIFIER, ((TypeContext)_localctx).type.ast), (((TypeContext)_localctx).IDENTIFIER!=null?((TypeContext)_localctx).IDENTIFIER.getText():null), ((TypeContext)_localctx).type.ast);
						v.add(c);
						v.addAll(((TypeContext)_localctx).type_args.ast);
						AstRecType t = new AstRecType(new Location((PrevToken)((TypeContext)_localctx).SIM_LSQLBR, (PrevToken)((TypeContext)_localctx).SIM_RSQLBR), new AstTrees<AstCompDecl>(v));
						((TypeContext)_localctx).ast =  t;
					

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case SIM_LPAR:
				enterOuterAlt(_localctx, 8);
				{
				setState(143);
				match(SIM_LPAR);
				setState(144);
				((TypeContext)_localctx).type = type();
				setState(145);
				match(SIM_RPAR);
				AstType t = ((TypeContext)_localctx).type.ast; 

						((TypeContext)_localctx).ast =  t;
					
				}
				break;
			case SIM_LSQRBR:
				enterOuterAlt(_localctx, 9);
				{
				setState(149);
				((TypeContext)_localctx).SIM_LSQRBR = match(SIM_LSQRBR);
				setState(150);
				((TypeContext)_localctx).declaration_binder = declaration_binder();
				setState(151);
				((TypeContext)_localctx).SIM_RSQRBR = match(SIM_RSQRBR);
				setState(152);
				((TypeContext)_localctx).type = type();
				 AstArrType t1 = new AstArrType(new Location((PrevToken)((TypeContext)_localctx).SIM_LSQRBR, (PrevToken)((TypeContext)_localctx).SIM_RSQRBR), ((TypeContext)_localctx).type.ast, ((TypeContext)_localctx).declaration_binder.ast); 

				        ((TypeContext)_localctx).ast =  t1;
				    
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_argsContext extends ParserRuleContext {
		public Vector<AstCompDecl> ast;
		public Token IDENTIFIER;
		public TypeContext type;
		public Type_argsContext type_args;
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Type_argsContext type_args() {
			return getRuleContext(Type_argsContext.class,0);
		}
		public Type_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_args; }
	}

	public final Type_argsContext type_args() throws RecognitionException {
		Type_argsContext _localctx = new Type_argsContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_type_args);
		try {
			setState(166);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(158);
				match(SIM_COM);
				setState(159);
				((Type_argsContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(160);
				match(SIM_COL);
				setState(161);
				((Type_argsContext)_localctx).type = type();
				setState(162);
				((Type_argsContext)_localctx).type_args = type_args();

						Vector v = new Vector<AstCompDecl>();
						AstCompDecl c = new AstCompDecl(new Location((PrevToken)((Type_argsContext)_localctx).IDENTIFIER, ((Type_argsContext)_localctx).type.ast), (((Type_argsContext)_localctx).IDENTIFIER!=null?((Type_argsContext)_localctx).IDENTIFIER.getText():null), ((Type_argsContext)_localctx).type.ast);
						v.add(c);
						v.addAll(((Type_argsContext)_localctx).type_args.ast);
						((Type_argsContext)_localctx).ast =  v;
					
				}
				break;
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{

						((Type_argsContext)_localctx).ast =  new Vector<AstCompDecl>();
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaration_binderContext extends ParserRuleContext {
		public AstExpr ast;
		public DisjunctiveContext disjunctive;
		public Declaration_binder_pContext declaration_binder_p;
		public DisjunctiveContext disjunctive() {
			return getRuleContext(DisjunctiveContext.class,0);
		}
		public Declaration_binder_pContext declaration_binder_p() {
			return getRuleContext(Declaration_binder_pContext.class,0);
		}
		public Declaration_binderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaration_binder; }
	}

	public final Declaration_binderContext declaration_binder() throws RecognitionException {
		Declaration_binderContext _localctx = new Declaration_binderContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_declaration_binder);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			((Declaration_binderContext)_localctx).disjunctive = disjunctive();
			 AstExpr e = ((Declaration_binderContext)_localctx).disjunctive.ast; 
			setState(170);
			((Declaration_binderContext)_localctx).declaration_binder_p = declaration_binder_p(e);

					((Declaration_binderContext)_localctx).ast =  ((Declaration_binderContext)_localctx).declaration_binder_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaration_binder_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public DeclContext decl;
		public Source_pContext source_p;
		public Token SIM_RSQLBR;
		public Declaration_binder_pContext declaration_binder_p;
		public TerminalNode KW_WHERE() { return getToken(PrevParser.KW_WHERE, 0); }
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public DeclContext decl() {
			return getRuleContext(DeclContext.class,0);
		}
		public Source_pContext source_p() {
			return getRuleContext(Source_pContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public Declaration_binder_pContext declaration_binder_p() {
			return getRuleContext(Declaration_binder_pContext.class,0);
		}
		public Declaration_binder_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Declaration_binder_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_declaration_binder_p; }
	}

	public final Declaration_binder_pContext declaration_binder_p(AstExpr e) throws RecognitionException {
		Declaration_binder_pContext _localctx = new Declaration_binder_pContext(_ctx, getState(), e);
		enterRule(_localctx, 16, RULE_declaration_binder_p);
		try {
			setState(183);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_WHERE:
				enterOuterAlt(_localctx, 1);
				{
				setState(173);
				match(KW_WHERE);
				setState(174);
				match(SIM_LSQLBR);
				setState(175);
				((Declaration_binder_pContext)_localctx).decl = decl();
				setState(176);
				((Declaration_binder_pContext)_localctx).source_p = source_p();
				setState(177);
				((Declaration_binder_pContext)_localctx).SIM_RSQLBR = match(SIM_RSQLBR);

						Vector <AstDecl> ds = new Vector <AstDecl>();
						ds.add(((Declaration_binder_pContext)_localctx).decl.ast);
						ds.addAll(((Declaration_binder_pContext)_localctx).source_p.ast);
						AstTrees a = new AstTrees<AstDecl>(ds);
						AstWhereExpr e1 = new AstWhereExpr(new Location(_localctx.e, (PrevToken)((Declaration_binder_pContext)_localctx).SIM_RSQLBR), _localctx.e, a);
					
				setState(179);
				((Declaration_binder_pContext)_localctx).declaration_binder_p = declaration_binder_p(e1);

						((Declaration_binder_pContext)_localctx).ast =  ((Declaration_binder_pContext)_localctx).declaration_binder_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_IS:
				enterOuterAlt(_localctx, 2);
				{

						((Declaration_binder_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DisjunctiveContext extends ParserRuleContext {
		public AstExpr ast;
		public ConjunctiveContext conjunctive;
		public Disjunctive_pContext disjunctive_p;
		public ConjunctiveContext conjunctive() {
			return getRuleContext(ConjunctiveContext.class,0);
		}
		public Disjunctive_pContext disjunctive_p() {
			return getRuleContext(Disjunctive_pContext.class,0);
		}
		public DisjunctiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_disjunctive; }
	}

	public final DisjunctiveContext disjunctive() throws RecognitionException {
		DisjunctiveContext _localctx = new DisjunctiveContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_disjunctive);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(185);
			((DisjunctiveContext)_localctx).conjunctive = conjunctive();

					AstExpr e = ((DisjunctiveContext)_localctx).conjunctive.ast;
				
			setState(187);
			((DisjunctiveContext)_localctx).disjunctive_p = disjunctive_p(e);

					((DisjunctiveContext)_localctx).ast =  ((DisjunctiveContext)_localctx).disjunctive_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Disjunctive_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public ConjunctiveContext conjunctive;
		public Disjunctive_pContext disjunctive_p;
		public TerminalNode SIM_LINE() { return getToken(PrevParser.SIM_LINE, 0); }
		public ConjunctiveContext conjunctive() {
			return getRuleContext(ConjunctiveContext.class,0);
		}
		public Disjunctive_pContext disjunctive_p() {
			return getRuleContext(Disjunctive_pContext.class,0);
		}
		public Disjunctive_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Disjunctive_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_disjunctive_p; }
	}

	public final Disjunctive_pContext disjunctive_p(AstExpr e) throws RecognitionException {
		Disjunctive_pContext _localctx = new Disjunctive_pContext(_ctx, getState(), e);
		enterRule(_localctx, 20, RULE_disjunctive_p);
		try {
			setState(197);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_LINE:
				enterOuterAlt(_localctx, 1);
				{
				setState(190);
				match(SIM_LINE);
				setState(191);
				((Disjunctive_pContext)_localctx).conjunctive = conjunctive();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Disjunctive_pContext)_localctx).conjunctive.ast), AstBinExpr.Oper.OR, _localctx.e, ((Disjunctive_pContext)_localctx).conjunctive.ast);
					
				setState(193);
				((Disjunctive_pContext)_localctx).disjunctive_p = disjunctive_p(ne);

						((Disjunctive_pContext)_localctx).ast =  ((Disjunctive_pContext)_localctx).disjunctive_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_IS:
				enterOuterAlt(_localctx, 2);
				{

						((Disjunctive_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConjunctiveContext extends ParserRuleContext {
		public AstExpr ast;
		public RelationalContext relational;
		public Conjunctive_pContext conjunctive_p;
		public RelationalContext relational() {
			return getRuleContext(RelationalContext.class,0);
		}
		public Conjunctive_pContext conjunctive_p() {
			return getRuleContext(Conjunctive_pContext.class,0);
		}
		public ConjunctiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conjunctive; }
	}

	public final ConjunctiveContext conjunctive() throws RecognitionException {
		ConjunctiveContext _localctx = new ConjunctiveContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_conjunctive);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(199);
			((ConjunctiveContext)_localctx).relational = relational();
			AstExpr e = ((ConjunctiveContext)_localctx).relational.ast;
			setState(201);
			((ConjunctiveContext)_localctx).conjunctive_p = conjunctive_p(e);

					((ConjunctiveContext)_localctx).ast =  ((ConjunctiveContext)_localctx).conjunctive_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Conjunctive_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public RelationalContext relational;
		public Conjunctive_pContext conjunctive_p;
		public TerminalNode SIM_AND() { return getToken(PrevParser.SIM_AND, 0); }
		public RelationalContext relational() {
			return getRuleContext(RelationalContext.class,0);
		}
		public Conjunctive_pContext conjunctive_p() {
			return getRuleContext(Conjunctive_pContext.class,0);
		}
		public Conjunctive_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Conjunctive_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_conjunctive_p; }
	}

	public final Conjunctive_pContext conjunctive_p(AstExpr e) throws RecognitionException {
		Conjunctive_pContext _localctx = new Conjunctive_pContext(_ctx, getState(), e);
		enterRule(_localctx, 24, RULE_conjunctive_p);
		try {
			setState(211);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_AND:
				enterOuterAlt(_localctx, 1);
				{
				setState(204);
				match(SIM_AND);
				setState(205);
				((Conjunctive_pContext)_localctx).relational = relational();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Conjunctive_pContext)_localctx).relational.ast), AstBinExpr.Oper.AND, _localctx.e, ((Conjunctive_pContext)_localctx).relational.ast);
					
				setState(207);
				((Conjunctive_pContext)_localctx).conjunctive_p = conjunctive_p(ne);

						((Conjunctive_pContext)_localctx).ast =  ((Conjunctive_pContext)_localctx).conjunctive_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_LINE:
			case SIM_IS:
				enterOuterAlt(_localctx, 2);
				{

						((Conjunctive_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RelationalContext extends ParserRuleContext {
		public AstExpr ast;
		public AdditiveContext additive;
		public Relational_pContext relational_p;
		public AdditiveContext additive() {
			return getRuleContext(AdditiveContext.class,0);
		}
		public Relational_pContext relational_p() {
			return getRuleContext(Relational_pContext.class,0);
		}
		public RelationalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relational; }
	}

	public final RelationalContext relational() throws RecognitionException {
		RelationalContext _localctx = new RelationalContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_relational);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(213);
			((RelationalContext)_localctx).additive = additive();
			AstExpr e = ((RelationalContext)_localctx).additive.ast;
			setState(215);
			((RelationalContext)_localctx).relational_p = relational_p(e);

					((RelationalContext)_localctx).ast =  ((RelationalContext)_localctx).relational_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Relational_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public AdditiveContext additive;
		public TerminalNode SIM_EQU() { return getToken(PrevParser.SIM_EQU, 0); }
		public AdditiveContext additive() {
			return getRuleContext(AdditiveContext.class,0);
		}
		public TerminalNode SIM_NEQU() { return getToken(PrevParser.SIM_NEQU, 0); }
		public TerminalNode SIM_LT() { return getToken(PrevParser.SIM_LT, 0); }
		public TerminalNode SIM_GT() { return getToken(PrevParser.SIM_GT, 0); }
		public TerminalNode SIM_LTEQU() { return getToken(PrevParser.SIM_LTEQU, 0); }
		public TerminalNode SIM_GTEQU() { return getToken(PrevParser.SIM_GTEQU, 0); }
		public Relational_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Relational_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_relational_p; }
	}

	public final Relational_pContext relational_p(AstExpr e) throws RecognitionException {
		Relational_pContext _localctx = new Relational_pContext(_ctx, getState(), e);
		enterRule(_localctx, 28, RULE_relational_p);
		try {
			setState(243);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_EQU:
				enterOuterAlt(_localctx, 1);
				{
				setState(218);
				match(SIM_EQU);
				setState(219);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.EQU, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case SIM_NEQU:
				enterOuterAlt(_localctx, 2);
				{
				setState(222);
				match(SIM_NEQU);
				setState(223);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.NEQ, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case SIM_LT:
				enterOuterAlt(_localctx, 3);
				{
				setState(226);
				match(SIM_LT);
				setState(227);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.LTH, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case SIM_GT:
				enterOuterAlt(_localctx, 4);
				{
				setState(230);
				match(SIM_GT);
				setState(231);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.GTH, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case SIM_LTEQU:
				enterOuterAlt(_localctx, 5);
				{
				setState(234);
				match(SIM_LTEQU);
				setState(235);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.LEQ, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case SIM_GTEQU:
				enterOuterAlt(_localctx, 6);
				{
				setState(238);
				match(SIM_GTEQU);
				setState(239);
				((Relational_pContext)_localctx).additive = additive();

						((Relational_pContext)_localctx).ast =  new AstBinExpr(new Location(_localctx.e, ((Relational_pContext)_localctx).additive.ast), AstBinExpr.Oper.GEQ, _localctx.e, ((Relational_pContext)_localctx).additive.ast);
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_AND:
			case SIM_LINE:
			case SIM_IS:
				enterOuterAlt(_localctx, 7);
				{

						((Relational_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AdditiveContext extends ParserRuleContext {
		public AstExpr ast;
		public MultiplicativeContext multiplicative;
		public Additive_pContext additive_p;
		public MultiplicativeContext multiplicative() {
			return getRuleContext(MultiplicativeContext.class,0);
		}
		public Additive_pContext additive_p() {
			return getRuleContext(Additive_pContext.class,0);
		}
		public AdditiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_additive; }
	}

	public final AdditiveContext additive() throws RecognitionException {
		AdditiveContext _localctx = new AdditiveContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_additive);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(245);
			((AdditiveContext)_localctx).multiplicative = multiplicative();
			 AstExpr e = ((AdditiveContext)_localctx).multiplicative.ast; 
			setState(247);
			((AdditiveContext)_localctx).additive_p = additive_p(e);

					((AdditiveContext)_localctx).ast =  ((AdditiveContext)_localctx).additive_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Additive_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public MultiplicativeContext multiplicative;
		public Additive_pContext additive_p;
		public TerminalNode SIM_PLUS() { return getToken(PrevParser.SIM_PLUS, 0); }
		public MultiplicativeContext multiplicative() {
			return getRuleContext(MultiplicativeContext.class,0);
		}
		public Additive_pContext additive_p() {
			return getRuleContext(Additive_pContext.class,0);
		}
		public TerminalNode SIM_MINUS() { return getToken(PrevParser.SIM_MINUS, 0); }
		public Additive_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Additive_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_additive_p; }
	}

	public final Additive_pContext additive_p(AstExpr e) throws RecognitionException {
		Additive_pContext _localctx = new Additive_pContext(_ctx, getState(), e);
		enterRule(_localctx, 32, RULE_additive_p);
		try {
			setState(263);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_PLUS:
				enterOuterAlt(_localctx, 1);
				{
				setState(250);
				match(SIM_PLUS);
				setState(251);
				((Additive_pContext)_localctx).multiplicative = multiplicative();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Additive_pContext)_localctx).multiplicative.ast), AstBinExpr.Oper.ADD, _localctx.e, ((Additive_pContext)_localctx).multiplicative.ast);
					
				setState(253);
				((Additive_pContext)_localctx).additive_p = additive_p(ne);

						((Additive_pContext)_localctx).ast =  ((Additive_pContext)_localctx).additive_p.ast;
					
				}
				break;
			case SIM_MINUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(256);
				match(SIM_MINUS);
				setState(257);
				((Additive_pContext)_localctx).multiplicative = multiplicative();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Additive_pContext)_localctx).multiplicative.ast), AstBinExpr.Oper.SUB, _localctx.e, ((Additive_pContext)_localctx).multiplicative.ast);
					
				setState(259);
				((Additive_pContext)_localctx).additive_p = additive_p(ne);

						((Additive_pContext)_localctx).ast =  ((Additive_pContext)_localctx).additive_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_AND:
			case SIM_LINE:
			case SIM_EQU:
			case SIM_NEQU:
			case SIM_LT:
			case SIM_GT:
			case SIM_LTEQU:
			case SIM_GTEQU:
			case SIM_IS:
				enterOuterAlt(_localctx, 3);
				{

						((Additive_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MultiplicativeContext extends ParserRuleContext {
		public AstExpr ast;
		public PrefixContext prefix;
		public Multiplicative_pContext multiplicative_p;
		public PrefixContext prefix() {
			return getRuleContext(PrefixContext.class,0);
		}
		public Multiplicative_pContext multiplicative_p() {
			return getRuleContext(Multiplicative_pContext.class,0);
		}
		public MultiplicativeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multiplicative; }
	}

	public final MultiplicativeContext multiplicative() throws RecognitionException {
		MultiplicativeContext _localctx = new MultiplicativeContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_multiplicative);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(265);
			((MultiplicativeContext)_localctx).prefix = prefix();
			AstExpr e = ((MultiplicativeContext)_localctx).prefix.ast;
			setState(267);
			((MultiplicativeContext)_localctx).multiplicative_p = multiplicative_p(e);

					((MultiplicativeContext)_localctx).ast =  ((MultiplicativeContext)_localctx).multiplicative_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Multiplicative_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public PrefixContext prefix;
		public Multiplicative_pContext multiplicative_p;
		public TerminalNode SIM_STAR() { return getToken(PrevParser.SIM_STAR, 0); }
		public PrefixContext prefix() {
			return getRuleContext(PrefixContext.class,0);
		}
		public Multiplicative_pContext multiplicative_p() {
			return getRuleContext(Multiplicative_pContext.class,0);
		}
		public TerminalNode SIM_SLH() { return getToken(PrevParser.SIM_SLH, 0); }
		public TerminalNode SIM_PRCNT() { return getToken(PrevParser.SIM_PRCNT, 0); }
		public Multiplicative_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Multiplicative_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_multiplicative_p; }
	}

	public final Multiplicative_pContext multiplicative_p(AstExpr e) throws RecognitionException {
		Multiplicative_pContext _localctx = new Multiplicative_pContext(_ctx, getState(), e);
		enterRule(_localctx, 36, RULE_multiplicative_p);
		try {
			setState(289);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_STAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(270);
				match(SIM_STAR);
				setState(271);
				((Multiplicative_pContext)_localctx).prefix = prefix();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast), AstBinExpr.Oper.MUL, _localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast);
					
				setState(273);
				((Multiplicative_pContext)_localctx).multiplicative_p = multiplicative_p(ne);

						((Multiplicative_pContext)_localctx).ast =  ((Multiplicative_pContext)_localctx).multiplicative_p.ast;
					
				}
				break;
			case SIM_SLH:
				enterOuterAlt(_localctx, 2);
				{
				setState(276);
				match(SIM_SLH);
				setState(277);
				((Multiplicative_pContext)_localctx).prefix = prefix();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast), AstBinExpr.Oper.DIV, _localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast);
					
				setState(279);
				((Multiplicative_pContext)_localctx).multiplicative_p = multiplicative_p(ne);

						((Multiplicative_pContext)_localctx).ast =  ((Multiplicative_pContext)_localctx).multiplicative_p.ast;
					
				}
				break;
			case SIM_PRCNT:
				enterOuterAlt(_localctx, 3);
				{
				setState(282);
				match(SIM_PRCNT);
				setState(283);
				((Multiplicative_pContext)_localctx).prefix = prefix();

						AstBinExpr ne = new AstBinExpr(new Location(_localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast), AstBinExpr.Oper.MOD, _localctx.e, ((Multiplicative_pContext)_localctx).prefix.ast);
					
				setState(285);
				((Multiplicative_pContext)_localctx).multiplicative_p = multiplicative_p(ne);

						((Multiplicative_pContext)_localctx).ast =  ((Multiplicative_pContext)_localctx).multiplicative_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_AND:
			case SIM_LINE:
			case SIM_EQU:
			case SIM_NEQU:
			case SIM_LT:
			case SIM_GT:
			case SIM_LTEQU:
			case SIM_GTEQU:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_IS:
				enterOuterAlt(_localctx, 4);
				{

						((Multiplicative_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrefixContext extends ParserRuleContext {
		public AstExpr ast;
		public Token SIM_EKSP;
		public PrefixContext prefix;
		public Token SIM_PLUS;
		public Token SIM_MINUS;
		public Token SIM_TOP;
		public Token KW_NEW;
		public Token KW_DEL;
		public PostfixContext postfix;
		public TerminalNode SIM_EKSP() { return getToken(PrevParser.SIM_EKSP, 0); }
		public PrefixContext prefix() {
			return getRuleContext(PrefixContext.class,0);
		}
		public TerminalNode SIM_PLUS() { return getToken(PrevParser.SIM_PLUS, 0); }
		public TerminalNode SIM_MINUS() { return getToken(PrevParser.SIM_MINUS, 0); }
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public TerminalNode KW_NEW() { return getToken(PrevParser.KW_NEW, 0); }
		public TerminalNode KW_DEL() { return getToken(PrevParser.KW_DEL, 0); }
		public PostfixContext postfix() {
			return getRuleContext(PostfixContext.class,0);
		}
		public PrefixContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prefix; }
	}

	public final PrefixContext prefix() throws RecognitionException {
		PrefixContext _localctx = new PrefixContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_prefix);
		try {
			setState(318);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_EKSP:
				enterOuterAlt(_localctx, 1);
				{
				setState(291);
				((PrefixContext)_localctx).SIM_EKSP = match(SIM_EKSP);
				setState(292);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).SIM_EKSP, ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.NOT, ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case SIM_PLUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(295);
				((PrefixContext)_localctx).SIM_PLUS = match(SIM_PLUS);
				setState(296);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).SIM_PLUS, ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.ADD, ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case SIM_MINUS:
				enterOuterAlt(_localctx, 3);
				{
				setState(299);
				((PrefixContext)_localctx).SIM_MINUS = match(SIM_MINUS);
				setState(300);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).SIM_MINUS, ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.SUB, ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case SIM_TOP:
				enterOuterAlt(_localctx, 4);
				{
				setState(303);
				((PrefixContext)_localctx).SIM_TOP = match(SIM_TOP);
				setState(304);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).SIM_TOP, ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.PTR, ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case KW_NEW:
				enterOuterAlt(_localctx, 5);
				{
				setState(307);
				((PrefixContext)_localctx).KW_NEW = match(KW_NEW);
				setState(308);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).KW_NEW , ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.NEW , ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case KW_DEL:
				enterOuterAlt(_localctx, 6);
				{
				setState(311);
				((PrefixContext)_localctx).KW_DEL = match(KW_DEL);
				setState(312);
				((PrefixContext)_localctx).prefix = prefix();

						AstPfxExpr ne = new AstPfxExpr(new Location((PrevToken)((PrefixContext)_localctx).KW_DEL, ((PrefixContext)_localctx).prefix.ast), AstPfxExpr.Oper.DEL, ((PrefixContext)_localctx).prefix.ast);
						((PrefixContext)_localctx).ast =  ne;
					
				}
				break;
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 7);
				{
				setState(315);
				((PrefixContext)_localctx).postfix = postfix();

						((PrefixContext)_localctx).ast =  ((PrefixContext)_localctx).postfix.ast;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PostfixContext extends ParserRuleContext {
		public AstExpr ast;
		public ExprContext expr;
		public Postfix_pContext postfix_p;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Postfix_pContext postfix_p() {
			return getRuleContext(Postfix_pContext.class,0);
		}
		public PostfixContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_postfix; }
	}

	public final PostfixContext postfix() throws RecognitionException {
		PostfixContext _localctx = new PostfixContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_postfix);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(320);
			((PostfixContext)_localctx).expr = expr();
			AstExpr e = ((PostfixContext)_localctx).expr.ast;
			setState(322);
			((PostfixContext)_localctx).postfix_p = postfix_p(e);

					((PostfixContext)_localctx).ast =  ((PostfixContext)_localctx).postfix_p.ast;
				
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Postfix_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public Declaration_binderContext declaration_binder;
		public Token SIM_RSQRBR;
		public Postfix_pContext postfix_p;
		public Token SIM_TOP;
		public Token IDENTIFIER;
		public TerminalNode SIM_LSQRBR() { return getToken(PrevParser.SIM_LSQRBR, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public TerminalNode SIM_RSQRBR() { return getToken(PrevParser.SIM_RSQRBR, 0); }
		public Postfix_pContext postfix_p() {
			return getRuleContext(Postfix_pContext.class,0);
		}
		public TerminalNode SIM_TOP() { return getToken(PrevParser.SIM_TOP, 0); }
		public TerminalNode SIM_DOT() { return getToken(PrevParser.SIM_DOT, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public Postfix_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Postfix_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_postfix_p; }
	}

	public final Postfix_pContext postfix_p(AstExpr e) throws RecognitionException {
		Postfix_pContext _localctx = new Postfix_pContext(_ctx, getState(), e);
		enterRule(_localctx, 42, RULE_postfix_p);
		try {
			setState(344);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_LSQRBR:
				enterOuterAlt(_localctx, 1);
				{
				setState(325);
				match(SIM_LSQRBR);
				setState(326);
				((Postfix_pContext)_localctx).declaration_binder = declaration_binder();
				setState(327);
				((Postfix_pContext)_localctx).SIM_RSQRBR = match(SIM_RSQRBR);

						AstArrExpr ne = new AstArrExpr (new Location(_localctx.e, (PrevToken)((Postfix_pContext)_localctx).SIM_RSQRBR), _localctx.e, ((Postfix_pContext)_localctx).declaration_binder.ast);
					
				setState(329);
				((Postfix_pContext)_localctx).postfix_p = postfix_p(ne);

						((Postfix_pContext)_localctx).ast =  ((Postfix_pContext)_localctx).postfix_p.ast;
					
				}
				break;
			case SIM_TOP:
				enterOuterAlt(_localctx, 2);
				{
				setState(332);
				((Postfix_pContext)_localctx).SIM_TOP = match(SIM_TOP);
				AstSfxExpr ne = new AstSfxExpr (new Location(_localctx.e, (PrevToken)((Postfix_pContext)_localctx).SIM_TOP), AstSfxExpr.Oper.PTR, _localctx.e);
				setState(334);
				((Postfix_pContext)_localctx).postfix_p = postfix_p(ne);

						((Postfix_pContext)_localctx).ast =  ((Postfix_pContext)_localctx).postfix_p.ast;
					
				}
				break;
			case SIM_DOT:
				enterOuterAlt(_localctx, 3);
				{
				setState(337);
				match(SIM_DOT);
				setState(338);
				((Postfix_pContext)_localctx).IDENTIFIER = match(IDENTIFIER);

						AstNameExpr ne1 = new AstNameExpr(new Location(_localctx.e, (PrevToken)((Postfix_pContext)_localctx).IDENTIFIER), (((Postfix_pContext)_localctx).IDENTIFIER!=null?((Postfix_pContext)_localctx).IDENTIFIER.getText():null));
						AstRecExpr ne2 = new AstRecExpr(new Location(_localctx.e, (PrevToken)((Postfix_pContext)_localctx).IDENTIFIER), _localctx.e, ne1);
					
				setState(340);
				((Postfix_pContext)_localctx).postfix_p = postfix_p(ne2);

						((Postfix_pContext)_localctx).ast =  ((Postfix_pContext)_localctx).postfix_p.ast;
					
				}
				break;
			case EOF:
			case KW_DO:
			case KW_ELSE:
			case KW_FUN:
			case KW_THEN:
			case KW_TYP:
			case KW_VAR:
			case KW_WHERE:
			case SIM_RPAR:
			case SIM_RSQLBR:
			case SIM_RSQRBR:
			case SIM_COM:
			case SIM_COL:
			case SIM_SCOL:
			case SIM_AND:
			case SIM_LINE:
			case SIM_EQU:
			case SIM_NEQU:
			case SIM_LT:
			case SIM_GT:
			case SIM_LTEQU:
			case SIM_GTEQU:
			case SIM_STAR:
			case SIM_SLH:
			case SIM_PRCNT:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_IS:
				enterOuterAlt(_localctx, 4);
				{

						((Postfix_pContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public AstExpr ast;
		public Token CONST_CHAR;
		public Token CONST_STRING;
		public Token CONST_INTEGER;
		public Token CONST_LITERAL;
		public Token CONST_BOOLEAN;
		public Token CONST_VOID;
		public Token IDENTIFIER;
		public Expr_pContext expr_p;
		public Token SIM_LSQLBR;
		public StmntContext stmnt;
		public Stmnt_argsContext stmnt_args;
		public Token SIM_RSQLBR;
		public Declaration_binderContext declaration_binder;
		public Expr_ppContext expr_pp;
		public TerminalNode CONST_CHAR() { return getToken(PrevParser.CONST_CHAR, 0); }
		public TerminalNode CONST_STRING() { return getToken(PrevParser.CONST_STRING, 0); }
		public TerminalNode CONST_INTEGER() { return getToken(PrevParser.CONST_INTEGER, 0); }
		public TerminalNode CONST_LITERAL() { return getToken(PrevParser.CONST_LITERAL, 0); }
		public TerminalNode CONST_BOOLEAN() { return getToken(PrevParser.CONST_BOOLEAN, 0); }
		public TerminalNode CONST_VOID() { return getToken(PrevParser.CONST_VOID, 0); }
		public TerminalNode IDENTIFIER() { return getToken(PrevParser.IDENTIFIER, 0); }
		public Expr_pContext expr_p() {
			return getRuleContext(Expr_pContext.class,0);
		}
		public TerminalNode SIM_LSQLBR() { return getToken(PrevParser.SIM_LSQLBR, 0); }
		public StmntContext stmnt() {
			return getRuleContext(StmntContext.class,0);
		}
		public TerminalNode SIM_SCOL() { return getToken(PrevParser.SIM_SCOL, 0); }
		public Stmnt_argsContext stmnt_args() {
			return getRuleContext(Stmnt_argsContext.class,0);
		}
		public TerminalNode SIM_RSQLBR() { return getToken(PrevParser.SIM_RSQLBR, 0); }
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public Expr_ppContext expr_pp() {
			return getRuleContext(Expr_ppContext.class,0);
		}
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_expr);
		try {
			setState(376);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(346);
				((ExprContext)_localctx).CONST_CHAR = match(CONST_CHAR);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_CHAR), AstAtomExpr.Type.CHAR, (((ExprContext)_localctx).CONST_CHAR!=null?((ExprContext)_localctx).CONST_CHAR.getText():null));
					
				}
				break;
			case CONST_STRING:
				enterOuterAlt(_localctx, 2);
				{
				setState(348);
				((ExprContext)_localctx).CONST_STRING = match(CONST_STRING);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_STRING), AstAtomExpr.Type.STRING, (((ExprContext)_localctx).CONST_STRING!=null?((ExprContext)_localctx).CONST_STRING.getText():null));
					
				}
				break;
			case CONST_INTEGER:
				enterOuterAlt(_localctx, 3);
				{
				setState(350);
				((ExprContext)_localctx).CONST_INTEGER = match(CONST_INTEGER);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_INTEGER), AstAtomExpr.Type.INTEGER, (((ExprContext)_localctx).CONST_INTEGER!=null?((ExprContext)_localctx).CONST_INTEGER.getText():null));
					
				}
				break;
			case CONST_LITERAL:
				enterOuterAlt(_localctx, 4);
				{
				setState(352);
				((ExprContext)_localctx).CONST_LITERAL = match(CONST_LITERAL);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_LITERAL), AstAtomExpr.Type.POINTER, (((ExprContext)_localctx).CONST_LITERAL!=null?((ExprContext)_localctx).CONST_LITERAL.getText():null));
					
				}
				break;
			case CONST_BOOLEAN:
				enterOuterAlt(_localctx, 5);
				{
				setState(354);
				((ExprContext)_localctx).CONST_BOOLEAN = match(CONST_BOOLEAN);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_BOOLEAN), AstAtomExpr.Type.BOOLEAN, (((ExprContext)_localctx).CONST_BOOLEAN!=null?((ExprContext)_localctx).CONST_BOOLEAN.getText():null));
					
				}
				break;
			case CONST_VOID:
				enterOuterAlt(_localctx, 6);
				{
				setState(356);
				((ExprContext)_localctx).CONST_VOID = match(CONST_VOID);

						((ExprContext)_localctx).ast =  new AstAtomExpr(new Location((PrevToken)((ExprContext)_localctx).CONST_VOID), AstAtomExpr.Type.VOID, (((ExprContext)_localctx).CONST_VOID!=null?((ExprContext)_localctx).CONST_VOID.getText():null));
					
				}
				break;
			case IDENTIFIER:
				enterOuterAlt(_localctx, 7);
				{
				setState(358);
				((ExprContext)_localctx).IDENTIFIER = match(IDENTIFIER);
				setState(359);
				((ExprContext)_localctx).expr_p = expr_p((((ExprContext)_localctx).IDENTIFIER!=null?((ExprContext)_localctx).IDENTIFIER.getText():null), (PrevToken)((ExprContext)_localctx).IDENTIFIER);

						if (((ExprContext)_localctx).expr_p.ast instanceof AstCallExpr){
							((ExprContext)_localctx).ast =  ((ExprContext)_localctx).expr_p.ast;
						}
						else {
							((ExprContext)_localctx).ast =  new AstNameExpr(new Location((PrevToken)((ExprContext)_localctx).IDENTIFIER), (((ExprContext)_localctx).IDENTIFIER!=null?((ExprContext)_localctx).IDENTIFIER.getText():null));
						}
					
				}
				break;
			case SIM_LSQLBR:
				enterOuterAlt(_localctx, 8);
				{
				setState(362);
				((ExprContext)_localctx).SIM_LSQLBR = match(SIM_LSQLBR);
				setState(363);
				((ExprContext)_localctx).stmnt = stmnt();
				setState(364);
				match(SIM_SCOL);
				setState(365);
				((ExprContext)_localctx).stmnt_args = stmnt_args();
				setState(366);
				((ExprContext)_localctx).SIM_RSQLBR = match(SIM_RSQLBR);

						Vector<AstStmt> s = new Vector<AstStmt>();
						s.add(((ExprContext)_localctx).stmnt.ast);
						s.addAll(((ExprContext)_localctx).stmnt_args.ast);
						((ExprContext)_localctx).ast =  new AstStmtExpr(new Location((PrevToken)((ExprContext)_localctx).SIM_LSQLBR, (PrevToken)((ExprContext)_localctx).SIM_RSQLBR), new AstTrees<AstStmt>(s));
					
				}
				break;
			case SIM_LPAR:
				enterOuterAlt(_localctx, 9);
				{
				setState(369);
				match(SIM_LPAR);
				setState(370);
				((ExprContext)_localctx).declaration_binder = declaration_binder();
				AstExpr e = ((ExprContext)_localctx).declaration_binder.ast;
				setState(372);
				((ExprContext)_localctx).expr_pp = expr_pp(e);
				setState(373);
				match(SIM_RPAR);

						if (((ExprContext)_localctx).expr_pp.ast instanceof AstCastExpr){
							((ExprContext)_localctx).ast =  ((ExprContext)_localctx).expr_pp.ast;
						}
						else {
							((ExprContext)_localctx).ast =  ((ExprContext)_localctx).declaration_binder.ast;
						}
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expr_pContext extends ParserRuleContext {
		public String s;
		public PrevToken identifier;
		public AstExpr ast;
		public Declaration_binderContext declaration_binder;
		public Expr_argsContext expr_args;
		public Token SIM_RPAR;
		public TerminalNode SIM_LPAR() { return getToken(PrevParser.SIM_LPAR, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public Expr_argsContext expr_args() {
			return getRuleContext(Expr_argsContext.class,0);
		}
		public TerminalNode SIM_RPAR() { return getToken(PrevParser.SIM_RPAR, 0); }
		public Expr_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Expr_pContext(ParserRuleContext parent, int invokingState, String s, PrevToken identifier) {
			super(parent, invokingState);
			this.s = s;
			this.identifier = identifier;
		}
		@Override public int getRuleIndex() { return RULE_expr_p; }
	}

	public final Expr_pContext expr_p(String s,PrevToken identifier) throws RecognitionException {
		Expr_pContext _localctx = new Expr_pContext(_ctx, getState(), s, identifier);
		enterRule(_localctx, 46, RULE_expr_p);
		try {
			setState(388);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{

						((Expr_pContext)_localctx).ast =  null;
					
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(379);
				match(SIM_LPAR);
				setState(380);
				((Expr_pContext)_localctx).declaration_binder = declaration_binder();
				setState(381);
				((Expr_pContext)_localctx).expr_args = expr_args();
				setState(382);
				((Expr_pContext)_localctx).SIM_RPAR = match(SIM_RPAR);

						Vector<AstExpr> a = new Vector<AstExpr>();
						a.add(((Expr_pContext)_localctx).declaration_binder.ast);
						a.addAll(((Expr_pContext)_localctx).expr_args.ast);
						AstTrees na = new AstTrees<AstExpr>(a);
						((Expr_pContext)_localctx).ast =  new AstCallExpr(new Location(identifier, (PrevToken)((Expr_pContext)_localctx).SIM_RPAR), s, na);
					
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(385);
				match(SIM_LPAR);
				setState(386);
				((Expr_pContext)_localctx).SIM_RPAR = match(SIM_RPAR);

						((Expr_pContext)_localctx).ast =  new AstCallExpr(new Location(identifier, (PrevToken)((Expr_pContext)_localctx).SIM_RPAR), s, new AstTrees<AstExpr>());
					
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expr_ppContext extends ParserRuleContext {
		public AstExpr e;
		public AstExpr ast;
		public TypeContext type;
		public TerminalNode SIM_COL() { return getToken(PrevParser.SIM_COL, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public Expr_ppContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Expr_ppContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_expr_pp; }
	}

	public final Expr_ppContext expr_pp(AstExpr e) throws RecognitionException {
		Expr_ppContext _localctx = new Expr_ppContext(_ctx, getState(), e);
		enterRule(_localctx, 48, RULE_expr_pp);
		try {
			setState(395);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COL:
				enterOuterAlt(_localctx, 1);
				{
				setState(390);
				match(SIM_COL);
				setState(391);
				((Expr_ppContext)_localctx).type = type();

						((Expr_ppContext)_localctx).ast =  new AstCastExpr(new Location(_localctx.e, ((Expr_ppContext)_localctx).type.ast), _localctx.e, ((Expr_ppContext)_localctx).type.ast);
					
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{

						((Expr_ppContext)_localctx).ast =  _localctx.e;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expr_argsContext extends ParserRuleContext {
		public Vector<AstExpr> ast;
		public Declaration_binderContext declaration_binder;
		public Expr_argsContext expr_args;
		public TerminalNode SIM_COM() { return getToken(PrevParser.SIM_COM, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public Expr_argsContext expr_args() {
			return getRuleContext(Expr_argsContext.class,0);
		}
		public Expr_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr_args; }
	}

	public final Expr_argsContext expr_args() throws RecognitionException {
		Expr_argsContext _localctx = new Expr_argsContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_expr_args);
		try {
			setState(403);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SIM_COM:
				enterOuterAlt(_localctx, 1);
				{
				setState(397);
				match(SIM_COM);
				setState(398);
				((Expr_argsContext)_localctx).declaration_binder = declaration_binder();
				setState(399);
				((Expr_argsContext)_localctx).expr_args = expr_args();

						Vector<AstExpr> a = new Vector<AstExpr>();
						a.add(((Expr_argsContext)_localctx).declaration_binder.ast);
						a.addAll(((Expr_argsContext)_localctx).expr_args.ast);
						((Expr_argsContext)_localctx).ast =  a;
					
				}
				break;
			case SIM_RPAR:
				enterOuterAlt(_localctx, 2);
				{

						((Expr_argsContext)_localctx).ast =  new Vector<AstExpr>();
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Stmnt_argsContext extends ParserRuleContext {
		public Vector<AstStmt> ast;
		public StmntContext stmnt;
		public Stmnt_argsContext stmnt_args;
		public StmntContext stmnt() {
			return getRuleContext(StmntContext.class,0);
		}
		public TerminalNode SIM_SCOL() { return getToken(PrevParser.SIM_SCOL, 0); }
		public Stmnt_argsContext stmnt_args() {
			return getRuleContext(Stmnt_argsContext.class,0);
		}
		public Stmnt_argsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stmnt_args; }
	}

	public final Stmnt_argsContext stmnt_args() throws RecognitionException {
		Stmnt_argsContext _localctx = new Stmnt_argsContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_stmnt_args);
		try {
			setState(411);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case KW_DEL:
			case KW_IF:
			case KW_NEW:
			case KW_WHILE:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
			case SIM_EKSP:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_TOP:
				enterOuterAlt(_localctx, 1);
				{
				setState(405);
				((Stmnt_argsContext)_localctx).stmnt = stmnt();
				setState(406);
				match(SIM_SCOL);
				setState(407);
				((Stmnt_argsContext)_localctx).stmnt_args = stmnt_args();

						Vector<AstStmt> s = new Vector<AstStmt>();
						s.add(((Stmnt_argsContext)_localctx).stmnt.ast);
						s.addAll(((Stmnt_argsContext)_localctx).stmnt_args.ast);
						((Stmnt_argsContext)_localctx).ast =  s;
					
				}
				break;
			case SIM_RSQLBR:
				enterOuterAlt(_localctx, 2);
				{

						((Stmnt_argsContext)_localctx).ast =  new Vector<AstStmt>();
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StmntContext extends ParserRuleContext {
		public AstStmt ast;
		public Declaration_binderContext declaration_binder;
		public Stmnt_pContext stmnt_p;
		public Token KW_IF;
		public StmntContext s1;
		public StmntContext s2;
		public Token KW_WHILE;
		public StmntContext stmnt;
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public Stmnt_pContext stmnt_p() {
			return getRuleContext(Stmnt_pContext.class,0);
		}
		public TerminalNode KW_IF() { return getToken(PrevParser.KW_IF, 0); }
		public TerminalNode KW_THEN() { return getToken(PrevParser.KW_THEN, 0); }
		public TerminalNode KW_ELSE() { return getToken(PrevParser.KW_ELSE, 0); }
		public List<StmntContext> stmnt() {
			return getRuleContexts(StmntContext.class);
		}
		public StmntContext stmnt(int i) {
			return getRuleContext(StmntContext.class,i);
		}
		public TerminalNode KW_WHILE() { return getToken(PrevParser.KW_WHILE, 0); }
		public TerminalNode KW_DO() { return getToken(PrevParser.KW_DO, 0); }
		public StmntContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stmnt; }
	}

	public final StmntContext stmnt() throws RecognitionException {
		StmntContext _localctx = new StmntContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_stmnt);
		try {
			setState(432);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST_CHAR:
			case CONST_STRING:
			case CONST_INTEGER:
			case CONST_LITERAL:
			case KW_DEL:
			case KW_NEW:
			case CONST_BOOLEAN:
			case CONST_VOID:
			case IDENTIFIER:
			case SIM_LPAR:
			case SIM_LSQLBR:
			case SIM_EKSP:
			case SIM_PLUS:
			case SIM_MINUS:
			case SIM_TOP:
				enterOuterAlt(_localctx, 1);
				{
				setState(413);
				((StmntContext)_localctx).declaration_binder = declaration_binder();
				AstExpr e = ((StmntContext)_localctx).declaration_binder.ast;
				setState(415);
				((StmntContext)_localctx).stmnt_p = stmnt_p(e);

						((StmntContext)_localctx).ast =  ((StmntContext)_localctx).stmnt_p.ast;
					
				}
				break;
			case KW_IF:
				enterOuterAlt(_localctx, 2);
				{
				setState(418);
				((StmntContext)_localctx).KW_IF = match(KW_IF);
				setState(419);
				((StmntContext)_localctx).declaration_binder = declaration_binder();
				setState(420);
				match(KW_THEN);
				setState(421);
				((StmntContext)_localctx).s1 = stmnt();
				setState(422);
				match(KW_ELSE);
				setState(423);
				((StmntContext)_localctx).s2 = stmnt();

						((StmntContext)_localctx).ast =  new AstIfStmt(new Location((PrevToken)((StmntContext)_localctx).KW_IF, ((StmntContext)_localctx).s2.ast), ((StmntContext)_localctx).declaration_binder.ast, ((StmntContext)_localctx).s1.ast, ((StmntContext)_localctx).s2.ast);
					
				}
				break;
			case KW_WHILE:
				enterOuterAlt(_localctx, 3);
				{
				setState(426);
				((StmntContext)_localctx).KW_WHILE = match(KW_WHILE);
				setState(427);
				((StmntContext)_localctx).declaration_binder = declaration_binder();
				setState(428);
				match(KW_DO);
				setState(429);
				((StmntContext)_localctx).stmnt = stmnt();

						((StmntContext)_localctx).ast =  new AstWhileStmt(new Location((PrevToken)((StmntContext)_localctx).KW_WHILE, ((StmntContext)_localctx).stmnt.ast), ((StmntContext)_localctx).declaration_binder.ast, ((StmntContext)_localctx).stmnt.ast);
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Stmnt_pContext extends ParserRuleContext {
		public AstExpr e;
		public AstStmt ast;
		public Declaration_binderContext declaration_binder;
		public TerminalNode SIM_IS() { return getToken(PrevParser.SIM_IS, 0); }
		public Declaration_binderContext declaration_binder() {
			return getRuleContext(Declaration_binderContext.class,0);
		}
		public Stmnt_pContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Stmnt_pContext(ParserRuleContext parent, int invokingState, AstExpr e) {
			super(parent, invokingState);
			this.e = e;
		}
		@Override public int getRuleIndex() { return RULE_stmnt_p; }
	}

	public final Stmnt_pContext stmnt_p(AstExpr e) throws RecognitionException {
		Stmnt_pContext _localctx = new Stmnt_pContext(_ctx, getState(), e);
		enterRule(_localctx, 56, RULE_stmnt_p);
		try {
			setState(439);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KW_ELSE:
			case SIM_SCOL:
				enterOuterAlt(_localctx, 1);
				{

						((Stmnt_pContext)_localctx).ast =  new AstExprStmt(new Location(_localctx.e), _localctx.e);
					
				}
				break;
			case SIM_IS:
				enterOuterAlt(_localctx, 2);
				{
				setState(435);
				match(SIM_IS);
				setState(436);
				((Stmnt_pContext)_localctx).declaration_binder = declaration_binder();

						((Stmnt_pContext)_localctx).ast =  new AstAssignStmt(new Location(_localctx.e, ((Stmnt_pContext)_localctx).declaration_binder.ast), _localctx.e, ((Stmnt_pContext)_localctx).declaration_binder.ast);
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\66\u01bc\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\3\2\3\2\3\2\3\2\3\2"+
		"\3\3\3\3\3\3\3\3\3\3\5\3G\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4"+
		"\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4`\n\4\3\5\3\5"+
		"\3\5\3\5\3\5\3\5\3\5\5\5i\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6s\n\6"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3"+
		"\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7\u009f\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b"+
		"\3\b\5\b\u00a9\n\b\3\t\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n"+
		"\3\n\3\n\5\n\u00ba\n\n\3\13\3\13\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3"+
		"\f\3\f\5\f\u00c8\n\f\3\r\3\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3\16"+
		"\3\16\5\16\u00d6\n\16\3\17\3\17\3\17\3\17\3\17\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\5\20\u00f6\n\20\3\21\3\21\3\21\3\21\3\21"+
		"\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\5\22"+
		"\u010a\n\22\3\23\3\23\3\23\3\23\3\23\3\24\3\24\3\24\3\24\3\24\3\24\3\24"+
		"\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\5\24\u0124"+
		"\n\24\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25"+
		"\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25"+
		"\5\25\u0141\n\25\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\27\3\27"+
		"\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\5\27"+
		"\u015b\n\27\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30"+
		"\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30"+
		"\3\30\3\30\3\30\3\30\5\30\u017b\n\30\3\31\3\31\3\31\3\31\3\31\3\31\3\31"+
		"\3\31\3\31\3\31\5\31\u0187\n\31\3\32\3\32\3\32\3\32\3\32\5\32\u018e\n"+
		"\32\3\33\3\33\3\33\3\33\3\33\3\33\5\33\u0196\n\33\3\34\3\34\3\34\3\34"+
		"\3\34\3\34\5\34\u019e\n\34\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35"+
		"\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\5\35\u01b3\n\35\3\36"+
		"\3\36\3\36\3\36\3\36\5\36\u01ba\n\36\3\36\2\2\37\2\4\6\b\n\f\16\20\22"+
		"\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:\2\2\2\u01d3\2<\3\2\2\2\4F\3"+
		"\2\2\2\6_\3\2\2\2\bh\3\2\2\2\nr\3\2\2\2\f\u009e\3\2\2\2\16\u00a8\3\2\2"+
		"\2\20\u00aa\3\2\2\2\22\u00b9\3\2\2\2\24\u00bb\3\2\2\2\26\u00c7\3\2\2\2"+
		"\30\u00c9\3\2\2\2\32\u00d5\3\2\2\2\34\u00d7\3\2\2\2\36\u00f5\3\2\2\2 "+
		"\u00f7\3\2\2\2\"\u0109\3\2\2\2$\u010b\3\2\2\2&\u0123\3\2\2\2(\u0140\3"+
		"\2\2\2*\u0142\3\2\2\2,\u015a\3\2\2\2.\u017a\3\2\2\2\60\u0186\3\2\2\2\62"+
		"\u018d\3\2\2\2\64\u0195\3\2\2\2\66\u019d\3\2\2\28\u01b2\3\2\2\2:\u01b9"+
		"\3\2\2\2<=\5\6\4\2=>\5\4\3\2>?\7\2\2\3?@\b\2\1\2@\3\3\2\2\2AB\5\6\4\2"+
		"BC\5\4\3\2CD\b\3\1\2DG\3\2\2\2EG\b\3\1\2FA\3\2\2\2FE\3\2\2\2G\5\3\2\2"+
		"\2HI\7\22\2\2IJ\7\31\2\2JK\7\63\2\2KL\5\f\7\2LM\b\4\1\2M`\3\2\2\2NO\7"+
		"\23\2\2OP\7\31\2\2PQ\7\"\2\2QR\5\f\7\2RS\b\4\1\2S`\3\2\2\2TU\7\r\2\2U"+
		"V\7\31\2\2VW\7\32\2\2WX\5\b\5\2XY\7\33\2\2YZ\7\"\2\2Z[\5\f\7\2[\\\7\63"+
		"\2\2\\]\5\20\t\2]^\b\4\1\2^`\3\2\2\2_H\3\2\2\2_N\3\2\2\2_T\3\2\2\2`\7"+
		"\3\2\2\2ai\b\5\1\2bc\7\31\2\2cd\7\"\2\2de\5\f\7\2ef\5\n\6\2fg\b\5\1\2"+
		"gi\3\2\2\2ha\3\2\2\2hb\3\2\2\2i\t\3\2\2\2jk\7!\2\2kl\7\31\2\2lm\7\"\2"+
		"\2mn\5\f\7\2no\5\n\6\2op\b\6\1\2ps\3\2\2\2qs\b\6\1\2rj\3\2\2\2rq\3\2\2"+
		"\2s\13\3\2\2\2tu\7\b\2\2uv\b\7\1\2v\u009f\b\7\1\2wx\7\t\2\2xy\b\7\1\2"+
		"y\u009f\b\7\1\2z{\7\17\2\2{|\b\7\1\2|\u009f\b\7\1\2}~\7\24\2\2~\177\b"+
		"\7\1\2\177\u009f\b\7\1\2\u0080\u0081\7\31\2\2\u0081\u0082\b\7\1\2\u0082"+
		"\u009f\b\7\1\2\u0083\u0084\7\62\2\2\u0084\u0085\5\f\7\2\u0085\u0086\b"+
		"\7\1\2\u0086\u0087\b\7\1\2\u0087\u009f\3\2\2\2\u0088\u0089\7\34\2\2\u0089"+
		"\u008a\7\31\2\2\u008a\u008b\7\"\2\2\u008b\u008c\5\f\7\2\u008c\u008d\5"+
		"\16\b\2\u008d\u008e\7\35\2\2\u008e\u008f\b\7\1\2\u008f\u0090\b\7\1\2\u0090"+
		"\u009f\3\2\2\2\u0091\u0092\7\32\2\2\u0092\u0093\5\f\7\2\u0093\u0094\7"+
		"\33\2\2\u0094\u0095\b\7\1\2\u0095\u0096\b\7\1\2\u0096\u009f\3\2\2\2\u0097"+
		"\u0098\7\36\2\2\u0098\u0099\5\20\t\2\u0099\u009a\7\37\2\2\u009a\u009b"+
		"\5\f\7\2\u009b\u009c\b\7\1\2\u009c\u009d\b\7\1\2\u009d\u009f\3\2\2\2\u009e"+
		"t\3\2\2\2\u009ew\3\2\2\2\u009ez\3\2\2\2\u009e}\3\2\2\2\u009e\u0080\3\2"+
		"\2\2\u009e\u0083\3\2\2\2\u009e\u0088\3\2\2\2\u009e\u0091\3\2\2\2\u009e"+
		"\u0097\3\2\2\2\u009f\r\3\2\2\2\u00a0\u00a1\7!\2\2\u00a1\u00a2\7\31\2\2"+
		"\u00a2\u00a3\7\"\2\2\u00a3\u00a4\5\f\7\2\u00a4\u00a5\5\16\b\2\u00a5\u00a6"+
		"\b\b\1\2\u00a6\u00a9\3\2\2\2\u00a7\u00a9\b\b\1\2\u00a8\u00a0\3\2\2\2\u00a8"+
		"\u00a7\3\2\2\2\u00a9\17\3\2\2\2\u00aa\u00ab\5\24\13\2\u00ab\u00ac\b\t"+
		"\1\2\u00ac\u00ad\5\22\n\2\u00ad\u00ae\b\t\1\2\u00ae\21\3\2\2\2\u00af\u00b0"+
		"\7\25\2\2\u00b0\u00b1\7\34\2\2\u00b1\u00b2\5\6\4\2\u00b2\u00b3\5\4\3\2"+
		"\u00b3\u00b4\7\35\2\2\u00b4\u00b5\b\n\1\2\u00b5\u00b6\5\22\n\2\u00b6\u00b7"+
		"\b\n\1\2\u00b7\u00ba\3\2\2\2\u00b8\u00ba\b\n\1\2\u00b9\u00af\3\2\2\2\u00b9"+
		"\u00b8\3\2\2\2\u00ba\23\3\2\2\2\u00bb\u00bc\5\30\r\2\u00bc\u00bd\b\13"+
		"\1\2\u00bd\u00be\5\26\f\2\u00be\u00bf\b\13\1\2\u00bf\25\3\2\2\2\u00c0"+
		"\u00c1\7%\2\2\u00c1\u00c2\5\30\r\2\u00c2\u00c3\b\f\1\2\u00c3\u00c4\5\26"+
		"\f\2\u00c4\u00c5\b\f\1\2\u00c5\u00c8\3\2\2\2\u00c6\u00c8\b\f\1\2\u00c7"+
		"\u00c0\3\2\2\2\u00c7\u00c6\3\2\2\2\u00c8\27\3\2\2\2\u00c9\u00ca\5\34\17"+
		"\2\u00ca\u00cb\b\r\1\2\u00cb\u00cc\5\32\16\2\u00cc\u00cd\b\r\1\2\u00cd"+
		"\31\3\2\2\2\u00ce\u00cf\7$\2\2\u00cf\u00d0\5\34\17\2\u00d0\u00d1\b\16"+
		"\1\2\u00d1\u00d2\5\32\16\2\u00d2\u00d3\b\16\1\2\u00d3\u00d6\3\2\2\2\u00d4"+
		"\u00d6\b\16\1\2\u00d5\u00ce\3\2\2\2\u00d5\u00d4\3\2\2\2\u00d6\33\3\2\2"+
		"\2\u00d7\u00d8\5 \21\2\u00d8\u00d9\b\17\1\2\u00d9\u00da\5\36\20\2\u00da"+
		"\u00db\b\17\1\2\u00db\35\3\2\2\2\u00dc\u00dd\7\'\2\2\u00dd\u00de\5 \21"+
		"\2\u00de\u00df\b\20\1\2\u00df\u00f6\3\2\2\2\u00e0\u00e1\7(\2\2\u00e1\u00e2"+
		"\5 \21\2\u00e2\u00e3\b\20\1\2\u00e3\u00f6\3\2\2\2\u00e4\u00e5\7)\2\2\u00e5"+
		"\u00e6\5 \21\2\u00e6\u00e7\b\20\1\2\u00e7\u00f6\3\2\2\2\u00e8\u00e9\7"+
		"*\2\2\u00e9\u00ea\5 \21\2\u00ea\u00eb\b\20\1\2\u00eb\u00f6\3\2\2\2\u00ec"+
		"\u00ed\7+\2\2\u00ed\u00ee\5 \21\2\u00ee\u00ef\b\20\1\2\u00ef\u00f6\3\2"+
		"\2\2\u00f0\u00f1\7,\2\2\u00f1\u00f2\5 \21\2\u00f2\u00f3\b\20\1\2\u00f3"+
		"\u00f6\3\2\2\2\u00f4\u00f6\b\20\1\2\u00f5\u00dc\3\2\2\2\u00f5\u00e0\3"+
		"\2\2\2\u00f5\u00e4\3\2\2\2\u00f5\u00e8\3\2\2\2\u00f5\u00ec\3\2\2\2\u00f5"+
		"\u00f0\3\2\2\2\u00f5\u00f4\3\2\2\2\u00f6\37\3\2\2\2\u00f7\u00f8\5$\23"+
		"\2\u00f8\u00f9\b\21\1\2\u00f9\u00fa\5\"\22\2\u00fa\u00fb\b\21\1\2\u00fb"+
		"!\3\2\2\2\u00fc\u00fd\7\60\2\2\u00fd\u00fe\5$\23\2\u00fe\u00ff\b\22\1"+
		"\2\u00ff\u0100\5\"\22\2\u0100\u0101\b\22\1\2\u0101\u010a\3\2\2\2\u0102"+
		"\u0103\7\61\2\2\u0103\u0104\5$\23\2\u0104\u0105\b\22\1\2\u0105\u0106\5"+
		"\"\22\2\u0106\u0107\b\22\1\2\u0107\u010a\3\2\2\2\u0108\u010a\b\22\1\2"+
		"\u0109\u00fc\3\2\2\2\u0109\u0102\3\2\2\2\u0109\u0108\3\2\2\2\u010a#\3"+
		"\2\2\2\u010b\u010c\5(\25\2\u010c\u010d\b\23\1\2\u010d\u010e\5&\24\2\u010e"+
		"\u010f\b\23\1\2\u010f%\3\2\2\2\u0110\u0111\7-\2\2\u0111\u0112\5(\25\2"+
		"\u0112\u0113\b\24\1\2\u0113\u0114\5&\24\2\u0114\u0115\b\24\1\2\u0115\u0124"+
		"\3\2\2\2\u0116\u0117\7.\2\2\u0117\u0118\5(\25\2\u0118\u0119\b\24\1\2\u0119"+
		"\u011a\5&\24\2\u011a\u011b\b\24\1\2\u011b\u0124\3\2\2\2\u011c\u011d\7"+
		"/\2\2\u011d\u011e\5(\25\2\u011e\u011f\b\24\1\2\u011f\u0120\5&\24\2\u0120"+
		"\u0121\b\24\1\2\u0121\u0124\3\2\2\2\u0122\u0124\b\24\1\2\u0123\u0110\3"+
		"\2\2\2\u0123\u0116\3\2\2\2\u0123\u011c\3\2\2\2\u0123\u0122\3\2\2\2\u0124"+
		"\'\3\2\2\2\u0125\u0126\7&\2\2\u0126\u0127\5(\25\2\u0127\u0128\b\25\1\2"+
		"\u0128\u0141\3\2\2\2\u0129\u012a\7\60\2\2\u012a\u012b\5(\25\2\u012b\u012c"+
		"\b\25\1\2\u012c\u0141\3\2\2\2\u012d\u012e\7\61\2\2\u012e\u012f\5(\25\2"+
		"\u012f\u0130\b\25\1\2\u0130\u0141\3\2\2\2\u0131\u0132\7\62\2\2\u0132\u0133"+
		"\5(\25\2\u0133\u0134\b\25\1\2\u0134\u0141\3\2\2\2\u0135\u0136\7\20\2\2"+
		"\u0136\u0137\5(\25\2\u0137\u0138\b\25\1\2\u0138\u0141\3\2\2\2\u0139\u013a"+
		"\7\n\2\2\u013a\u013b\5(\25\2\u013b\u013c\b\25\1\2\u013c\u0141\3\2\2\2"+
		"\u013d\u013e\5*\26\2\u013e\u013f\b\25\1\2\u013f\u0141\3\2\2\2\u0140\u0125"+
		"\3\2\2\2\u0140\u0129\3\2\2\2\u0140\u012d\3\2\2\2\u0140\u0131\3\2\2\2\u0140"+
		"\u0135\3\2\2\2\u0140\u0139\3\2\2\2\u0140\u013d\3\2\2\2\u0141)\3\2\2\2"+
		"\u0142\u0143\5.\30\2\u0143\u0144\b\26\1\2\u0144\u0145\5,\27\2\u0145\u0146"+
		"\b\26\1\2\u0146+\3\2\2\2\u0147\u0148\7\36\2\2\u0148\u0149\5\20\t\2\u0149"+
		"\u014a\7\37\2\2\u014a\u014b\b\27\1\2\u014b\u014c\5,\27\2\u014c\u014d\b"+
		"\27\1\2\u014d\u015b\3\2\2\2\u014e\u014f\7\62\2\2\u014f\u0150\b\27\1\2"+
		"\u0150\u0151\5,\27\2\u0151\u0152\b\27\1\2\u0152\u015b\3\2\2\2\u0153\u0154"+
		"\7 \2\2\u0154\u0155\7\31\2\2\u0155\u0156\b\27\1\2\u0156\u0157\5,\27\2"+
		"\u0157\u0158\b\27\1\2\u0158\u015b\3\2\2\2\u0159\u015b\b\27\1\2\u015a\u0147"+
		"\3\2\2\2\u015a\u014e\3\2\2\2\u015a\u0153\3\2\2\2\u015a\u0159\3\2\2\2\u015b"+
		"-\3\2\2\2\u015c\u015d\7\4\2\2\u015d\u017b\b\30\1\2\u015e\u015f\7\5\2\2"+
		"\u015f\u017b\b\30\1\2\u0160\u0161\7\6\2\2\u0161\u017b\b\30\1\2\u0162\u0163"+
		"\7\7\2\2\u0163\u017b\b\30\1\2\u0164\u0165\7\27\2\2\u0165\u017b\b\30\1"+
		"\2\u0166\u0167\7\30\2\2\u0167\u017b\b\30\1\2\u0168\u0169\7\31\2\2\u0169"+
		"\u016a\5\60\31\2\u016a\u016b\b\30\1\2\u016b\u017b\3\2\2\2\u016c\u016d"+
		"\7\34\2\2\u016d\u016e\58\35\2\u016e\u016f\7#\2\2\u016f\u0170\5\66\34\2"+
		"\u0170\u0171\7\35\2\2\u0171\u0172\b\30\1\2\u0172\u017b\3\2\2\2\u0173\u0174"+
		"\7\32\2\2\u0174\u0175\5\20\t\2\u0175\u0176\b\30\1\2\u0176\u0177\5\62\32"+
		"\2\u0177\u0178\7\33\2\2\u0178\u0179\b\30\1\2\u0179\u017b\3\2\2\2\u017a"+
		"\u015c\3\2\2\2\u017a\u015e\3\2\2\2\u017a\u0160\3\2\2\2\u017a\u0162\3\2"+
		"\2\2\u017a\u0164\3\2\2\2\u017a\u0166\3\2\2\2\u017a\u0168\3\2\2\2\u017a"+
		"\u016c\3\2\2\2\u017a\u0173\3\2\2\2\u017b/\3\2\2\2\u017c\u0187\b\31\1\2"+
		"\u017d\u017e\7\32\2\2\u017e\u017f\5\20\t\2\u017f\u0180\5\64\33\2\u0180"+
		"\u0181\7\33\2\2\u0181\u0182\b\31\1\2\u0182\u0187\3\2\2\2\u0183\u0184\7"+
		"\32\2\2\u0184\u0185\7\33\2\2\u0185\u0187\b\31\1\2\u0186\u017c\3\2\2\2"+
		"\u0186\u017d\3\2\2\2\u0186\u0183\3\2\2\2\u0187\61\3\2\2\2\u0188\u0189"+
		"\7\"\2\2\u0189\u018a\5\f\7\2\u018a\u018b\b\32\1\2\u018b\u018e\3\2\2\2"+
		"\u018c\u018e\b\32\1\2\u018d\u0188\3\2\2\2\u018d\u018c\3\2\2\2\u018e\63"+
		"\3\2\2\2\u018f\u0190\7!\2\2\u0190\u0191\5\20\t\2\u0191\u0192\5\64\33\2"+
		"\u0192\u0193\b\33\1\2\u0193\u0196\3\2\2\2\u0194\u0196\b\33\1\2\u0195\u018f"+
		"\3\2\2\2\u0195\u0194\3\2\2\2\u0196\65\3\2\2\2\u0197\u0198\58\35\2\u0198"+
		"\u0199\7#\2\2\u0199\u019a\5\66\34\2\u019a\u019b\b\34\1\2\u019b\u019e\3"+
		"\2\2\2\u019c\u019e\b\34\1\2\u019d\u0197\3\2\2\2\u019d\u019c\3\2\2\2\u019e"+
		"\67\3\2\2\2\u019f\u01a0\5\20\t\2\u01a0\u01a1\b\35\1\2\u01a1\u01a2\5:\36"+
		"\2\u01a2\u01a3\b\35\1\2\u01a3\u01b3\3\2\2\2\u01a4\u01a5\7\16\2\2\u01a5"+
		"\u01a6\5\20\t\2\u01a6\u01a7\7\21\2\2\u01a7\u01a8\58\35\2\u01a8\u01a9\7"+
		"\f\2\2\u01a9\u01aa\58\35\2\u01aa\u01ab\b\35\1\2\u01ab\u01b3\3\2\2\2\u01ac"+
		"\u01ad\7\26\2\2\u01ad\u01ae\5\20\t\2\u01ae\u01af\7\13\2\2\u01af\u01b0"+
		"\58\35\2\u01b0\u01b1\b\35\1\2\u01b1\u01b3\3\2\2\2\u01b2\u019f\3\2\2\2"+
		"\u01b2\u01a4\3\2\2\2\u01b2\u01ac\3\2\2\2\u01b39\3\2\2\2\u01b4\u01ba\b"+
		"\36\1\2\u01b5\u01b6\7\63\2\2\u01b6\u01b7\5\20\t\2\u01b7\u01b8\b\36\1\2"+
		"\u01b8\u01ba\3\2\2\2\u01b9\u01b4\3\2\2\2\u01b9\u01b5\3\2\2\2\u01ba;\3"+
		"\2\2\2\27F_hr\u009e\u00a8\u00b9\u00c7\u00d5\u00f5\u0109\u0123\u0140\u015a"+
		"\u017a\u0186\u018d\u0195\u019d\u01b2\u01b9";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}