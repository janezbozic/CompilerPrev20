/**
 * Intermediate code generation.
 */
package prev.phase.imcgen;
