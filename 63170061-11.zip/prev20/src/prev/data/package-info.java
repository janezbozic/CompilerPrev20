/**
 * Data structures used by various phases.
 */
package prev.data;