/**
 * Register allocation.
 */
package prev.phase.regall;