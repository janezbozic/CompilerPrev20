package prev.data.ast.tree;

/**
 * A name.
 */
public interface AstName extends AstTree {

}
