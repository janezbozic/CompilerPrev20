/**
 * Abstract syntax tree construction.
 */
package prev.phase.abstr;