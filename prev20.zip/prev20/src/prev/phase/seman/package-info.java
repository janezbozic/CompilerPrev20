/**
 * Semantic analysis.
 */
package prev.phase.seman;
