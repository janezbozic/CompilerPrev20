/**
 * Intermediate code instructions denoting expressions.
 */
package prev.data.imc.code.expr;
