/**
 * Abstract syntax tree attributes.
 */
package prev.data.ast.attribute;
