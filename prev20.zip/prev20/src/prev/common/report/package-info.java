/**
 * Infrastructure for reporting to the user.
 */
package prev.common.report;
