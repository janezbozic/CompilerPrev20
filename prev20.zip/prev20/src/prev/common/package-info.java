/**
 * Code used by all compiler phases.
 */
package prev.common;