/**
 * Intermediate code instructions.
 */
package prev.data.imc.code;
